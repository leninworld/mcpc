/**
 * Unit tests for OAuth flow utility functions
 */

import { OAuthError, OAuthErrorCode } from '@modelcontextprotocol/client';
import { validateClientMetadataUrl } from '../../../../src/lib/auth/oauth-utils.js';
import {
  assertHttpAuthorizationUrl,
  explainOAuthRegistrationFailure,
  extractCodeFromUrl,
  startCallbackServer,
  getBrowserOpenCommand,
} from '../../../../src/lib/auth/oauth-flow.js';
import { AuthError } from '../../../../src/lib/errors.js';

describe('explainOAuthRegistrationFailure', () => {
  const serverUrl = 'https://mcp.figma.com/mcp';
  const preAuth = { serverUrl, reachedAuthorization: false };

  it('rewrites the SDK non-JSON 403 error (Figma) into allow-list guidance', () => {
    // The exact error the MCP SDK surfaces for Figma's plain-text "Forbidden" body.
    const raw = new OAuthError(
      OAuthErrorCode.ServerError,
      "HTTP 403: Invalid OAuth error response: SyntaxError: Unexpected token 'F', " +
        '"Forbidden" is not valid JSON. Raw body: Forbidden'
    );

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    const message = (result as AuthError).message;
    expect(message).toContain('mcp.figma.com refused to register mcpc');
    expect(message).toContain('(HTTP 403)');
    expect(message).toContain('--client-id');
    expect(message).toContain('--client-metadata-url');
    // The underlying server response stays visible (login prints only error.message).
    expect(message).toContain('Server response:');
    expect(message).toContain('Raw body: Forbidden');
    expect((result as AuthError).details).toEqual({ originalError: raw.message });
  });

  it('recognizes a 401/403 registration rejection even when the error is untyped', () => {
    const raw = new Error('HTTP 401: Invalid OAuth error response: foo. Raw body: Unauthorized');

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    expect((result as AuthError).message).toContain('refused to register mcpc');
  });

  it('recognizes OAuth-coded client rejections without an HTTP status', () => {
    const raw = new OAuthError(OAuthErrorCode.InvalidClient, 'mcpc is not an approved client');

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    const message = (result as AuthError).message;
    expect(message).toContain('refused to register mcpc as an OAuth client.');
    expect(message).toContain('Server response: mcpc is not an approved client');
  });

  it('explains servers that expose no registration endpoint', () => {
    const raw = new Error('Incompatible auth server: does not support dynamic client registration');

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    const message = (result as AuthError).message;
    expect(message).toContain('does not support Dynamic Client Registration');
    expect(message).toContain('--client-id');
    expect(message).toContain('--client-secret');
    // The redirect URL to pre-register with the provider is spelled out.
    expect(message).toContain('http://127.0.0.1:13316/callback');
  });

  it('keeps the full server URL in the suggested login commands', () => {
    // Asana: `/v2/mcp` delegates to app.asana.com (no DCR), while the bare host
    // is a different, deprecated authorization server. A host-only hint would
    // send the user to the wrong one.
    const asanaUrl = 'https://mcp.asana.com/v2/mcp';
    const raw = new Error('Incompatible auth server: does not support dynamic client registration');

    const result = explainOAuthRegistrationFailure(raw, {
      serverUrl: asanaUrl,
      reachedAuthorization: false,
    });

    const message = (result as AuthError).message;
    expect(message).toContain('mcp.asana.com does not support Dynamic Client Registration');
    expect(message).toContain(`mcpc login ${asanaUrl} --client-id <id>`);
    expect(message).toContain(`mcpc login ${asanaUrl} --client-metadata-url`);
    expect(message).not.toContain('mcpc login mcp.asana.com ');
  });

  it('does not claim an allow-list for a registration 5xx', () => {
    const raw = new OAuthError(
      OAuthErrorCode.ServerError,
      'HTTP 500: Invalid OAuth error response: SyntaxError: bad. Raw body: <html>outage</html>'
    );

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    const message = (result as AuthError).message;
    expect(message).toContain('Client registration with mcp.figma.com failed:');
    expect(message).not.toContain('refused to register');
    expect(message).not.toContain('allow-list');
    expect(message).toContain('--client-id');
  });

  it('reports rejected client metadata without claiming an allow-list', () => {
    const raw = new OAuthError(OAuthErrorCode.InvalidClientMetadata, 'redirect_uri is not allowed');

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    expect(result).toBeInstanceOf(AuthError);
    const message = (result as AuthError).message;
    expect(message).toContain('Client registration with mcp.figma.com failed:');
    expect(message).toContain('redirect_uri is not allowed');
    expect(message).not.toContain('refused to register');
  });

  it('truncates oversized response bodies in the message but keeps details intact', () => {
    const body = 'x'.repeat(2000);
    const raw = new OAuthError(
      OAuthErrorCode.ServerError,
      `HTTP 403: Invalid OAuth error response: bad. Raw body: ${body}`
    );

    const result = explainOAuthRegistrationFailure(raw, preAuth);

    const message = (result as AuthError).message;
    expect(message).toContain('…');
    expect(message).not.toContain(body);
    expect((result as AuthError).details).toEqual({ originalError: raw.message });
  });

  it('leaves the error unchanged once authorization has been reached', () => {
    // A 403 after the redirect is a token-exchange failure, not registration.
    const raw = new OAuthError(
      OAuthErrorCode.ServerError,
      'HTTP 403: Invalid OAuth error response. Raw body: Forbidden'
    );

    const result = explainOAuthRegistrationFailure(raw, { serverUrl, reachedAuthorization: true });

    expect(result).toBe(raw);
  });

  it('leaves unrelated pre-authorization errors unchanged', () => {
    for (const raw of [
      new Error('connect ECONNREFUSED 127.0.0.1:3845'),
      new Error('Forbidden'), // no HTTP status, not an SDK OAuth error
      new Error('Authentication cancelled by user'),
    ]) {
      expect(explainOAuthRegistrationFailure(raw, preAuth)).toBe(raw);
    }
  });
});

describe('validateClientMetadataUrl', () => {
  it('accepts a valid HTTPS URL with path', () => {
    expect(() =>
      validateClientMetadataUrl('https://example.com/client-metadata/v1.json')
    ).not.toThrow();
  });

  it('accepts a URL with a port', () => {
    expect(() => validateClientMetadataUrl('https://example.com:8443/client.json')).not.toThrow();
  });

  it('rejects a non-HTTPS URL', () => {
    expect(() => validateClientMetadataUrl('http://example.com/client.json')).toThrow(
      /"https" scheme/
    );
  });

  it('rejects a URL without a path component', () => {
    expect(() => validateClientMetadataUrl('https://example.com')).toThrow(/path component/);
  });

  it('rejects a URL with only a root path', () => {
    expect(() => validateClientMetadataUrl('https://example.com/')).toThrow(/path component/);
  });

  it('rejects an invalid URL', () => {
    expect(() => validateClientMetadataUrl('not-a-url')).toThrow(/not a valid URL/);
  });

  it('rejects a URL with a fragment', () => {
    expect(() => validateClientMetadataUrl('https://example.com/client.json#section')).toThrow(
      /fragment/
    );
  });

  it('rejects a URL with a username', () => {
    expect(() => validateClientMetadataUrl('https://user@example.com/client.json')).toThrow(
      /username or password/
    );
  });

  it('rejects a URL with a username and password', () => {
    expect(() => validateClientMetadataUrl('https://user:pass@example.com/client.json')).toThrow(
      /username or password/
    );
  });

  it('rejects a URL with single-dot path segment', () => {
    expect(() => validateClientMetadataUrl('https://example.com/./client.json')).toThrow(
      /path segments/
    );
  });

  it('rejects a URL with double-dot path segment', () => {
    expect(() => validateClientMetadataUrl('https://example.com/../client.json')).toThrow(
      /path segments/
    );
  });

  it('accepts a URL with a query string', () => {
    expect(() => validateClientMetadataUrl('https://example.com/client.json?v=1')).not.toThrow();
  });
});

describe('getBrowserOpenCommand', () => {
  const platforms: NodeJS.Platform[] = ['darwin', 'win32', 'linux', 'freebsd', 'openbsd', 'sunos'];
  // The authorization URL is server-controlled, so cmd.exe-style metacharacters are
  // realistic input: `&` and `|` would be command separators under `cmd.exe /c start`.
  const hostile = new URL('https://evil.example/authorize?client_id=1&calc|whoami^%PATH%#frag');

  it.each(platforms)('never launches a shell or command interpreter on %s', (platform) => {
    const { command } = getBrowserOpenCommand(hostile, platform);
    expect(command).not.toMatch(/cmd(\.exe)?$/i);
    expect(command).not.toMatch(/powershell|pwsh/i);
    expect(command).not.toMatch(/(^|\/)(ba|z|da)?sh$/);
    expect(command).not.toMatch(/^start$/i);
  });

  it.each(platforms)('passes the URL through verbatim as a single argument on %s', (platform) => {
    const { args } = getBrowserOpenCommand(hostile, platform);
    expect(args[args.length - 1]).toBe(hostile.toString());
    expect(args.filter((a) => a.includes('evil.example'))).toHaveLength(1);
  });

  it('uses rundll32 url.dll,FileProtocolHandler on Windows', () => {
    expect(getBrowserOpenCommand(new URL('https://auth.example/authorize'), 'win32')).toEqual({
      command: 'rundll32',
      args: ['url.dll,FileProtocolHandler', 'https://auth.example/authorize'],
    });
  });

  it('uses open on macOS and xdg-open elsewhere', () => {
    const url = new URL('https://auth.example/authorize?x=1');
    expect(getBrowserOpenCommand(url, 'darwin')).toEqual({
      command: 'open',
      args: [url.toString()],
    });
    expect(getBrowserOpenCommand(url, 'linux')).toEqual({
      command: 'xdg-open',
      args: [url.toString()],
    });
  });

  it('serialises whitespace and quotes so the argument cannot be split or re-quoted', () => {
    const url = new URL('https://auth.example/authorize?redirect="x y"');
    const { args } = getBrowserOpenCommand(url, 'win32');
    expect(args[1]).not.toMatch(/[\s"]/);
    expect(args[1]).toBe('https://auth.example/authorize?redirect=%22x%20y%22');
  });

  it.each(['http://127.0.0.1:8080/authorize', 'https://auth.example/authorize'])(
    'accepts %s',
    (url) => {
      expect(() => getBrowserOpenCommand(new URL(url), 'linux')).not.toThrow();
    }
  );

  it.each([
    'javascript:alert(1)',
    'file:///etc/passwd',
    'ms-msdt:/id PCWDiagnostic',
    'ftp://auth.example/authorize',
    'mailto:victim@example.com',
  ])('rejects the non-http(s) authorization URL %s on every platform', (url) => {
    for (const platform of platforms) {
      expect(() => getBrowserOpenCommand(new URL(url), platform)).toThrow(AuthError);
    }
  });
});

describe('assertHttpAuthorizationUrl', () => {
  it('names the offending scheme and refuses to open it', () => {
    expect(() => assertHttpAuthorizationUrl(new URL('javascript:alert(1)'))).toThrow(
      /unsupported scheme "javascript:".*Refusing to open/
    );
  });

  it('allows http and https', () => {
    expect(() => assertHttpAuthorizationUrl(new URL('http://localhost/a'))).not.toThrow();
    expect(() => assertHttpAuthorizationUrl(new URL('https://a.example/b'))).not.toThrow();
  });
});

describe('OAuth callback server verifies the state parameter (M1)', () => {
  const context = { serverUrl: 'https://mcp.example.com', profileName: 'default' };

  type Started = ReturnType<typeof startCallbackServer> & { base: string };
  const started: Started[] = [];

  const listen = async (): Promise<Started> => {
    const callback = startCallbackServer(0, context);
    await new Promise<void>((resolve) => callback.server.listen(0, '127.0.0.1', resolve));
    const { port } = callback.server.address() as { port: number };
    const entry = { ...callback, base: `http://127.0.0.1:${port}` };
    started.push(entry);
    return entry;
  };

  const settled = (promise: Promise<unknown>): Promise<'resolved' | 'rejected' | 'pending'> =>
    Promise.race([
      promise.then(
        () => 'resolved' as const,
        () => 'rejected' as const
      ),
      new Promise<'pending'>((resolve) => setTimeout(() => resolve('pending'), 50)),
    ]);

  afterEach(() => {
    for (const entry of started.splice(0)) {
      entry.destroyConnections();
      entry.server.close();
    }
  });

  it('resolves with the code when the callback echoes the expected state', async () => {
    const cb = await listen();
    cb.expectState('expected-state');
    const res = await fetch(`${cb.base}/callback?code=abc&state=expected-state&iss=https://as`);
    expect(res.status).toBe(200);
    await expect(cb.codePromise).resolves.toEqual({
      code: 'abc',
      state: 'expected-state',
      iss: 'https://as',
    });
  });

  it('ignores a callback with a foreign or missing state: no code, no abort, 400 to the sender', async () => {
    const cb = await listen();
    cb.expectState('expected-state');

    const foreign = await fetch(`${cb.base}/callback?code=attacker&state=other`);
    expect(foreign.status).toBe(400);
    expect(await foreign.text()).toContain('ignored');
    expect(await settled(cb.codePromise)).toBe('pending');

    const missing = await fetch(`${cb.base}/callback?code=attacker`);
    expect(missing.status).toBe(400);
    expect(await settled(cb.codePromise)).toBe('pending');

    // An attacker-sent error must not abort the login either.
    const error = await fetch(`${cb.base}/callback?error=access_denied&state=other`);
    expect(error.status).toBe(400);
    expect(await settled(cb.codePromise)).toBe('pending');

    // The genuine callback still goes through afterwards.
    await fetch(`${cb.base}/callback?code=real&state=expected-state`);
    await expect(cb.codePromise).resolves.toMatchObject({ code: 'real' });
  });

  it('ignores every callback before the authorization URL is known', async () => {
    const cb = await listen();
    const res = await fetch(`${cb.base}/callback?code=early&state=anything`);
    expect(res.status).toBe(400);
    expect(await settled(cb.codePromise)).toBe('pending');
  });

  it('rejects on a genuine error callback without crashing the process when no handler is attached yet', async () => {
    const unhandled: unknown[] = [];
    const onUnhandled = (reason: unknown): void => {
      unhandled.push(reason);
    };
    process.on('unhandledRejection', onUnhandled);
    try {
      const cb = await listen();
      cb.expectState('expected-state');
      const res = await fetch(
        `${cb.base}/callback?error=access_denied&error_description=nope&state=expected-state`
      );
      expect(res.status).toBe(400);
      // Give the microtask queue and the unhandled-rejection tracker a turn.
      await new Promise((resolve) => setTimeout(resolve, 20));
      expect(unhandled).toEqual([]);
      // The flow's own handler, attached later, still sees the rejection.
      await expect(cb.codePromise).rejects.toThrow('OAuth error: nope');
    } finally {
      process.off('unhandledRejection', onUnhandled);
    }
  });
});

describe('extractCodeFromUrl verifies the state parameter (M1)', () => {
  it('accepts a pasted callback URL that echoes the state', () => {
    expect(
      extractCodeFromUrl('http://127.0.0.1:13316/callback?code=abc&state=s1&iss=https://as', 's1')
    ).toEqual({ code: 'abc', state: 's1', iss: 'https://as' });
    expect(extractCodeFromUrl('/callback?code=abc&state=s1', 's1')).toEqual({
      code: 'abc',
      state: 's1',
    });
  });

  it('refuses a pasted URL with a missing or mismatched state before looking at code or error', () => {
    expect(() => extractCodeFromUrl('http://127.0.0.1:13316/callback?code=abc', 's1')).toThrow(
      /does not belong to this login/
    );
    expect(() =>
      extractCodeFromUrl('http://127.0.0.1:13316/callback?code=abc&state=s2', 's1')
    ).toThrow(/does not belong to this login/);
    expect(() =>
      extractCodeFromUrl('http://127.0.0.1:13316/callback?error=access_denied&state=s2', 's1')
    ).toThrow(/does not belong to this login/);
  });
});
