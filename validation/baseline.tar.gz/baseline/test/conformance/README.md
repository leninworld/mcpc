# MCP conformance tests

These tests run the reference [`@modelcontextprotocol/conformance`](https://github.com/modelcontextprotocol/conformance)
suite against mcpc. The framework starts a purpose-built server per scenario,
runs `client.mjs` (the adapter) against it, and records checks based on what the
server observed on the wire. It tests mcpc as a real user drives it — the
adapter only ever invokes the `mcpc` binary.

Run one scenario locally:

```bash
pnpm run build
npx -y @modelcontextprotocol/conformance client \
  --command "node test/conformance/client.mjs" \
  --scenario auth/client-credentials-basic \
  --timeout 180000
```

List everything the framework offers with
`npx -y @modelcontextprotocol/conformance list --client`.

In CI the scenarios run via `.github/workflows/conformance.yml`, which the
release workflow depends on — a conformance regression blocks a release.

## Keeping these in sync

**Conformance scenarios are part of the test surface, like the e2e suites.**
When a change touches protocol behaviour, the OAuth flows, or transport
handling, check whether a scenario covers it and update the adapter in the same
PR — the same rule that applies to `test/e2e`. Two failure modes to avoid:

- A deliberate behaviour change breaks the adapter, and the break is only
  discovered when a release is gated (this happened in #329/#331).
- A new feature ships with a scenario already available upstream and nobody
  wires it up.

When upgrading the conformance package, re-run `list --client` and check for
newly added scenarios.

## Covered

| Scenario | What it pins down |
| --- | --- |
| `initialize` | Handshake, then the list-style commands against a minimal server |
| `tools_call` | `tools-list`/`tools-get`/`tools-call` argument-parsing paths; `--task` is refused when the server has no `tasks` capability |
| `auth/client-credentials-basic` | `login --grant client-credentials` with `client_secret_basic`, incl. RFC 9728 discovery of an authorization server on another origin |
| `auth/client-credentials-jwt` | The same via `private_key_jwt` (`--client-key`), signed with ES256 |
| `dns-rebinding-protection` | Server scenario, run through `mcpc connect --proxy` by `server.mjs` (see below): the proxy rejects non-loopback `Host`/`Origin` headers and accepts loopback ones |

`sse-retry` is implemented but excluded from default runs: it surfaces a known
mcpc SSE-reconnect timing issue. Run it explicitly with
`gh workflow run conformance.yml -f scenario=sse-retry`.

## Not covered yet

The interactive `auth/*` scenarios — metadata discovery variants, CIMD, scope
selection and step-up, token-endpoint auth methods, pre-registration,
2025-03-26 backcompat, and the SEP-990 cross-app-access flow — all drive the
authorization-code grant, which opens a browser. Supporting them needs the
adapter to intercept the browser launch and complete the redirect itself; the
non-interactive client-credentials scenarios above were wired up first because
they need no such scaffolding.

`elicitation-sep1034-client-defaults` is intentionally out of scope: mcpc
implements no elicitation (it never prompts for input, the same reason sampling
is unsupported).

Completions (`completion/complete`, the `completion-complete` command) have no
client-side scenario upstream: the suite's `completion-complete` scenario
exercises servers, not clients. The e2e suites cover the client against both
test servers instead.

The `io.modelcontextprotocol/skills` extension has no client scenario upstream
yet. It is exercised by `test/e2e/suites/basic/skills.test.sh` (against the
2026-07-28 test server) in the meantime; wire up a scenario here as soon as one
appears in `list --client`.

The same goes for the `io.modelcontextprotocol/tasks` extension (MCP 2026-07-28):
no client scenario upstream yet. `test/e2e/suites/sessions/tasks-extension.test.sh`
covers it against the 2026-07-28 test server (server-directed task creation, the
`tasks/get` poll loop and its inlined result, the `Mcp-Name` routing header,
cooperative cancellation, `input_required`), and `sessions/async-tasks.test.sh`
runs the shared command surface in both eras. The `tools_call` scenario's
`--task` refusal above stays a 2025-11-25 check: the conformance server neither
advertises the `tasks` capability nor declares the extension.

Note that the framework's client scenarios currently top out at protocol
`2025-11-25`, so these runs exercise mcpc's legacy fallback path rather than the
`2026-07-28` era it negotiates by default.

## Proxy server conformance

Run the first server-side scenario from #334 against a real `mcpc connect --proxy` chain:

```bash
pnpm run build
node test/conformance/server.mjs
```

The runner starts the existing local e2e server, connects an isolated named session, and binds its proxy to `127.0.0.1`. The reference `dns-rebinding-protection` scenario checks rejection of invalid Host/Origin headers and acceptance of valid localhost requests. Readiness and commands are bounded; session and server cleanup run on success, failure and interruption. No remote MCP service or credentials are required.

The server lane runs by default in the reusable conformance workflow, so it also gates releases. Like the existing client lane it resolves the conformance package through `npx -y`; set `CONFORMANCE_PACKAGE_VERSION` to a published version for a pinned local run. Remaining server scenarios need fixtures and are not covered yet.
